package amortization

import (
	"math"
	"math/rand"
	"strconv"
	"testing"
	"time"

	"github.com/persense/persense-port/internal/types"
)

// TestDOSFancyCombinationSweep validates CO-OCCURRING advanced options against
// the real DOS engine per-row. The existing TestDOSFancyOptionsSweep /
// per-row sweeps each exercise ONE option at a time; this drives several at once
// (balloon + adjustment, balloon + skip, adjustment + skip, balloon + moratorium,
// adjustment + target, and a balloon+moratorium+skip triple) — the combinatorial
// interaction that's most likely to expose an order-of-operations divergence.
func TestDOSFancyCombinationSweep(t *testing.T) {
	gateOracle(t)
	rng := rand.New(rand.NewSource(20260712))

	// Option builders. Each returns an oracle token plus a Go mutation that sets
	// the matching LoanInput field. Months are spaced by the caller to avoid two
	// options colliding on the same period.
	balloon := func(month int, amt float64) (string, func(*LoanInput)) {
		by, bm := 2024+month/12, time.Month(month%12+1)
		return "b" + strconv.Itoa(month) + "=" + strconv.FormatFloat(amt, 'f', 2, 64),
			func(in *LoanInput) {
				in.Balloons = append(in.Balloons, BalloonPayment{
					DateStatus: types.InOutInput, Date: types.NewDateRec(by, bm, 1),
					AmountStatus: types.InOutInput, Amount: amt})
			}
	}
	adjustRate := func(month int, newRate float64) (string, func(*LoanInput)) {
		ay, am := 2024+month/12, time.Month(month%12+1)
		// Round-trip through the SAME 6-dp text the oracle token carries, so Go
		// and DOS amortize an identical adjustment rate. Handing Go the
		// unrounded float while the oracle only ever sees six decimals makes the
		// two engines solve slightly different loans, and the gap compounds over
		// the post-adjustment tail: it surfaced (2026-07-24, §45) as a phantom
		// ~$0.09 balance mismatch on the second-to-last row of a $474k/80-period
		// adjust+target case — DOS 392.71 vs Go 392.62 — with every interest
		// figure matching to the cent, which is the signature of a rate epsilon
		// rather than a logic divergence. Feeding both sides 0.097973 closes it
		// to under two cents. The `target` builder below already does this.
		s := strconv.FormatFloat(newRate, 'f', 6, 64)
		quantized, _ := strconv.ParseFloat(s, 64)
		return "adj=" + strconv.Itoa(month) + ":" + s + ":",
			func(in *LoanInput) {
				in.Adjustments = append(in.Adjustments, RateAdjustment{
					DateStatus: types.InOutInput, Date: types.NewDateRec(ay, am, 1),
					LoanRateStatus: types.InOutInput, LoanRate: quantized})
			}
	}
	skip := func(str string) (string, func(*LoanInput)) {
		ms, _ := MonthSetFromString(str)
		return "skip=" + str, func(in *LoanInput) {
			in.SkipMonths = SkipMonths{SkipStatus: types.InOutInput, SkipStr: str, MonthSet: ms}
		}
	}
	moratorium := func(month int) (string, func(*LoanInput)) {
		my, mm := 2024+month/12, time.Month(month%12+1)
		return "mor=" + strconv.Itoa(month), func(in *LoanInput) {
			in.Moratorium = Moratorium{FirstRepayStatus: types.InOutInput, FirstRepay: types.NewDateRec(my, mm, 1)}
		}
	}
	target := func(amt float64) (string, func(*LoanInput)) {
		s := strconv.FormatFloat(amt, 'f', 2, 64)
		return "targ=" + s, func(in *LoanInput) {
			v, _ := strconv.ParseFloat(s, 64)
			in.Target = Target{TargetStatus: types.InOutInput, TargetValue: v}
		}
	}

	// ALL combinations are per-row bit-faithful and asserted. The former
	// "adjustment interaction" gap (balloon+adjust / adjust+skip / adjust+target,
	// once docs/amort_adjustment_combination_finding.md) was a TEST-HARNESS BUG,
	// not an engine divergence: adjustRate emitted the oracle token `adj=M:R:0`,
	// whose trailing `0` sets the ADJUSTMENT PAYMENT to $0 (interest-only) in DOS,
	// while the Go mutation applied a rate-only change — so Go and DOS amortized
	// different loans. Fixed to emit `adj=M:R:` (rate-only, blank amount); every
	// combo now matches DOS to the cent, so all are asserted. (2026-07-16 re-audit.)
	cleanCombo := map[string]bool{
		"balloon+skip": true, "balloon+mor": true, "triple": true,
		"balloon+adjust": true, "adjust+skip": true, "adjust+target": true,
	}
	combos := []string{"balloon+adjust", "balloon+skip", "adjust+skip", "balloon+mor", "adjust+target", "triple"}
	for _, combo := range combos {
		checked, skipped, countFails, valFails := 0, 0, 0, 0
		maxRel := 0.0
		for i := 0; i < 120; i++ {
			amount := float64(50000 + rng.Intn(450000))
			rate := 0.04 + rng.Float64()*0.06
			n := 36 + rng.Intn(48)
			pay, ok0 := runOraclePayment(amount, rate, n, 12)
			if !ok0 {
				skipped++
				continue
			}

			var toks []string
			var muts []func(*LoanInput)
			add := func(tok string, mut func(*LoanInput)) { toks = append(toks, tok); muts = append(muts, mut) }

			switch combo {
			case "balloon+adjust":
				tk, mu := balloon(n/2, float64(5000+rng.Intn(20000)))
				add(tk, mu)
				tk, mu = adjustRate(n/4, rate+0.01+rng.Float64()*0.02)
				add(tk, mu)
			case "balloon+skip":
				tk, mu := balloon(n/2, float64(5000+rng.Intn(20000)))
				add(tk, mu)
				tk, mu = skip(strconv.Itoa(3+rng.Intn(4)) + "-" + strconv.Itoa(7+rng.Intn(3)))
				add(tk, mu)
			case "adjust+skip":
				tk, mu := adjustRate(n/3, rate+0.01+rng.Float64()*0.02)
				add(tk, mu)
				tk, mu = skip(strconv.Itoa(3 + rng.Intn(3)))
				add(tk, mu)
			case "balloon+mor":
				tk, mu := moratorium(2 + rng.Intn(4))
				add(tk, mu)
				tk, mu = balloon(n*2/3, float64(5000+rng.Intn(20000)))
				add(tk, mu)
			case "adjust+target":
				tk, mu := adjustRate(n/3, rate+0.01+rng.Float64()*0.02)
				add(tk, mu)
				tk, mu = target(pay * (0.55 + rng.Float64()*0.3))
				add(tk, mu)
			case "triple":
				tk, mu := moratorium(2 + rng.Intn(3))
				add(tk, mu)
				tk, mu = balloon(n*2/3, float64(5000+rng.Intn(15000)))
				add(tk, mu)
				tk, mu = skip(strconv.Itoa(12 + rng.Intn(3)))
				add(tk, mu)
			}

			gp, gok := goFancyRows(amount, rate, pay, n, func(in *LoanInput) {
				for _, mu := range muts {
					mu(in)
				}
			})
			if !gok {
				skipped++
				continue
			}
			dosRows, ok := runOracleRowsFlags(amount, rate, n, 12, pay, toks...)
			if !ok {
				skipped++
				continue
			}
			checked++
			if len(dosRows) != len(gp) {
				countFails++
				if cleanCombo[combo] && countFails <= 4 {
					t.Errorf("[%s] ROW COUNT amt=%.0f r=%.4f n=%d toks=%v: DOS=%d Go=%d",
						combo, amount, rate, n, toks, len(dosRows), len(gp))
				}
				continue
			}
			for k := 0; k < len(dosRows)-1; k++ {
				di := math.Abs(dosRows[k].interest - gp[k].Interest)
				db := math.Abs(dosRows[k].balance - gp[k].Principal)
				if rb := db / math.Max(1, math.Abs(gp[k].Principal)); rb > maxRel {
					maxRel = rb
				}
				if di > 0.02+1e-4*math.Abs(gp[k].Interest) || db > 0.02+1e-4*math.Abs(gp[k].Principal) {
					valFails++
					if cleanCombo[combo] && valFails <= 6 {
						t.Errorf("[%s] ROW amt=%.0f r=%.12f pay=%.10f n=%d toks=%v row=%d: int DOS=%.2f Go=%.2f | bal DOS=%.2f Go=%.2f",
							combo, amount, rate, pay, n, toks, k+1, dosRows[k].interest, gp[k].Interest, dosRows[k].balance, gp[k].Principal)
					}
				}
			}
		}
		status := "ASSERTED"
		if !cleanCombo[combo] {
			status = "DOCUMENTED GAP (adjustment interaction; see docs/amort_adjustment_combination_finding.md)"
		}
		t.Logf("[%s, %s] combination per-row: checked %d, skipped %d, count fails %d, value fails %d, max bal relErr=%.2e",
			combo, status, checked, skipped, countFails, valFails, maxRel)
	}
}
