// Backward calculation paths for the present value screen.
//
// The DOS PRESVALU.pas program supports field-presence-driven dispatch:
// the user fills in some fields and leaves others blank, and the program
// chooses a formula to solve for whatever is missing. This file ports the
// classification (FirstPass) and the solver paths (BackwardCalc plus the
// rate / as-of solvers that DOS embedded in FrontwardCalc).
//
// Mapping of solve paths to DOS source:
//
//   PV-1  lump-sum amount given date+value  -> PRESVALU.pas:866-891
//   PV-2  lump-sum date given amount+value  -> PRESVALU.pas:892-931 (Newton)
//   PV-4  periodic amount given dates+value -> PRESVALU.pas:943-956
//   PV-5  periodic toDate given fromDate+amount+value -> PRESVALU.pas:965-999
//   PV-6  periodic fromDate given toDate+amount+value -> PRESVALU.pas:1000-1070
//   PV-8  rate given full payment list + sumvalue -> PRESVALU.pas:693-754
//   PV-9  asof given rate + payments + sumvalue   -> PRESVALU.pas:755-818
//
// Ported from legacy/src/dos_source/PRESVALU.pas.

package presentvalue

import (
	"errors"
	"fmt"
	"math"
	"time"

	"github.com/persense/persense-port/internal/dateutil"
	"github.com/persense/persense-port/internal/finance/actuarial"
	"github.com/persense/persense-port/internal/finance/interest"
	"github.com/persense/persense-port/internal/types"
)

// lumpRowPV returns a lump-sum row's present value at (rate, asof),
// weighted by the survival probability when the row is
// life-contingent — matching the forward path (calc.go:331).
func lumpRowPV(ls *LumpSumPayment, asof types.DateRec, rate float64,
	settings *PVSettings, actu *actuarial.ActuarialConfig) (float64, error) {
	v, err := LumpSumValue(ls.Amt, ls.Date, asof, rate, settings.Basis, settings.YrInv)
	if err != nil {
		return 0, err
	}
	if actu != nil && ls.Act != actuarial.NotContingent {
		v *= actu.LifeProb(ls.Date, ls.Act)
	}
	return v, nil
}

// periodicRowPV returns a periodic row's present value at (rate,
// asof), weighted by survival probability when life-contingent.
func periodicRowPV(pp *PeriodicPayment, asof types.DateRec, rate float64,
	settings *PVSettings, actu *actuarial.ActuarialConfig) (float64, error) {
	cola := pp.COLA
	if pp.COLAStatus < types.InOutDefault {
		cola = 0
	}
	nInst := pp.NInstallments
	if nInst <= 0 {
		nInst = estimateInstallments(pp.FromDate, pp.ToDate, pp.PerYr)
	}
	if actu != nil && pp.Act != actuarial.NotContingent {
		// periodicWithActuarial returns the survival-weighted present-value
		// factor PER UNIT of payment, exactly like PeriodicSummation below.
		// The forward path multiplies it by the amount (calc.go:471,
		// pp.Val = pp.Amt * val), and the DOS backward known-sum subtracts
		// each row's full value valn = amt * summation (PRESVALU.pas:860-862).
		// So this must return amt * factor too — returning the bare factor
		// dropped the payment amount, mis-valuing every life-contingent
		// periodic row inside a backward solve by a factor of the amount.
		// Amount passed only to dollar-scale the per-payment detail, which
		// the backward path discards; the returned factor is per-unit.
		val, _, _ := periodicWithActuarial(pp.Amt, rate, cola, asof, pp.FromDate, pp.ToDate,
			pp.PerYr, nInst, settings, actu, pp.Act)
		return pp.Amt * val, nil
	}
	ty, tm, td := pp.rawTo()
	factor, err := PeriodicSummationRawTo(rate, cola, asof, pp.FromDate, pp.ToDate,
		ty, tm, td, pp.PerYr, nInst, settings)
	if err != nil {
		return 0, err
	}
	return pp.Amt * factor, nil
}

// weightedPeriodicFactor returns the present-value factor PER UNIT of a
// periodic payment over [from, to], survival-weighted when the row is
// life-contingent — exactly the factor the forward path applies
// (periodicWithActuarial vs PeriodicSummation). The backward amount and
// date solvers must invert this SAME factor, mirroring DOS where
// Summation folds in LifeProb under fold_in_life (PRESVALU.pas:397).
// Without the weighting, a contingent date or amount solve lands on the
// unweighted answer and fails to round-trip.
func weightedPeriodicFactor(input *PVInput, pp *PeriodicPayment, from, to, asof types.DateRec,
	rate, cola float64, n int, settings *PVSettings) (float64, error) {
	if input.Actuarial != nil && pp.Act != actuarial.NotContingent {
		f, _, _ := periodicWithActuarial(pp.Amt, rate, cola, asof, from, to,
			pp.PerYr, n, settings, input.Actuarial, pp.Act)
		return f, nil
	}
	return PeriodicSummation(rate, cola, asof, from, to, pp.PerYr, n, settings)
}

// rowStatus is the per-row classification produced by FirstPass.
// Mirrors DOS LineBlank..LineOverDetermined defined in types.constants.go.
type rowStatus byte

// FirstPassResult holds the status classification of the screen.
//
// frontward = true means the screen has enough data to compute the
// SumValue from the input fields (any number of fully_specified rows
// and no rows with missing data).
//
// backward = true means exactly one input field is missing somewhere
// and SumValue is known, so we can solve for the missing field.
//
// Both flags being true means the screen is over-determined ("Too many
// unknowns") and the caller should report an error to the user.
type FirstPassResult struct {
	Frontward bool
	Backward  bool
	// BackwardKind identifies which kind of unknown the caller can
	// solve for. Only populated when Backward is true.
	BackwardKind BackwardKind
	// BackwardIndex is the row index (0-based) when BackwardKind
	// targets a lump-sum or periodic row.
	BackwardIndex int
	// LumpSumStatus and PeriodicStatus carry the per-row status flag
	// set by FirstPass so callers can render hints / errors.
	LumpSumStatus  []byte
	PeriodicStatus []byte
	// Err is set when FirstPass detects an unrecoverable problem
	// (e.g. dates out of order, value but no date or amount).
	Err error
	// Warnings carries non-fatal advisories — e.g. an over-specified
	// row whose redundant Value will be recomputed. DOS surfaces these
	// as cancelable warnings (PRESVALU.pas:1166-1189); the port
	// continues the calculation and reports them alongside the result.
	Warnings []string
}

// BackwardKind identifies which field the backward calc will solve for.
type BackwardKind int

const (
	BackwardNone           BackwardKind = iota
	BackwardLumpAmount                  // PV-1
	BackwardLumpDate                    // PV-2
	BackwardPeriodicAmount              // PV-4
	BackwardPeriodicToDate              // PV-5
	BackwardPeriodicFrom                // PV-6
	BackwardRate                        // PV-8
	BackwardAsOf                        // PV-9
)

// FirstPass walks the screen state and assigns each row a status code.
// It then sets Frontward / Backward dispatch flags following the rules
// in PRESVALU.pas: procedure FirstPass (lines 544-654).
//
// Frontward is true if every populated row has fully_specified status.
// Backward is true if exactly one row contains_unknown AND the
// SumValue is provided in the present-value line.
//
// Ported from legacy/src/dos_source/PRESVALU.pas: procedure FirstPass.
func FirstPass(input *PVInput) FirstPassResult {
	res := FirstPassResult{
		LumpSumStatus:  make([]byte, len(input.LumpSums)),
		PeriodicStatus: make([]byte, len(input.Periodics)),
	}

	// Block 3: PresVal line classification.
	// In DOS this is YieldRateTranslation -> sets c[k]^.status to
	// missing_3 (rate, asof, sumvalue all missing) up to fully_specified.
	pv := &input.PresVal

	// BLOCK 2 - Periodic block. PRESVALU.pas:594-629.
	for j := range input.Periodics {
		b := &input.Periodics[j]

		// Date order check (PRESVALU.pas:599-604), followed by the Through-date
		// snap DOS performs in the same breath (PRESVALU.pas:605-608):
		//
		//   if (DateComp(fromdate, todate) >= 0) then <error>
		//   else begin
		//     saveto := todate;
		//     ninstallments := NumberOfInstallments(fromdate,todate,peryr,on_or_before);
		//     if (DateComp(saveto,todate) <> 0) then todatestatus := defp;
		//   end;
		//
		// NumberOfInstallments takes `l` as a VAR parameter and rewrites it to
		// the last actual payment date (INTSUTIL.pas:936-1040 ChoosePaymentDate).
		// When the user's Through date falls short of one full payment period
		// after the From date, that snap collapses Through ONTO From.
		//
		// Enter then runs FirstPass a SECOND time (PRESVALU.pas:1158 and again
		// at :1192, "because this information has been lost in ClearOutputCells"),
		// and that second pass re-reads the now-collapsed pair as
		// DateComp(from, to) = 0 >= 0 and raises the out-of-order error, with
		// :1194 `if (errorflag) then exit` abandoning the calculation. So DOS
		// REFUSES any periodic row with fewer than two installments — e.g.
		// 1/1/2030 through 1/15/2030 monthly, or 6/23/2033 through 1/23/2034
		// annually. The port previously snapped without re-checking and happily
		// valued such a row as a single payment.
		//
		// The snap is idempotent (a Through date already sitting on a payment
		// date is left alone), which is exactly why DOS's two passes agree on
		// every row that isn't collapsed.
		if b.FromDateStatus >= types.InOutDefault &&
			b.ToDateStatus >= types.InOutDefault &&
			b.PerYrStatus >= types.InOutDefault &&
			b.PerYr > 0 {
			outOfOrder := dateutil.DateComp(b.FromDate, b.ToDate) >= 0
			if !outOfOrder {
				saveTo := b.ToDate
				_, ty, tm, td, err := dateutil.NumberOfInstallmentsRawE(
					b.FromDate, b.ToDate, b.PerYr, types.OnOrBefore)
				// This is DOS's FIRST and only NumberOfInstallments call on the
				// Through date, and therefore the first place its 26/52 arm can
				// hand back MDY's poisoned record (see
				// dateutil.ErrJulianCeiling). DOS carries the poison forward —
				// `todatestatus := defp`, no out-of-order (DateComp orders an
				// unusable date last), and the row keeps going — until something
				// calls Julian on it, which fires EMessage("Bad date passed to
				// Julian function: m=-99") and the screen refuses.
				//
				// The port refuses HERE, at the point the information still
				// exists. It cannot be deferred: `setRawTo` below replaces
				// ToDate with the unknown date, so every later guard reads
				// Julian = -88 instead of the user's 70097 — which is exactly
				// what defeated four guard placements on 2026-07-30.
				//
				// A FOREVER row never gets here: NumberOfInstallments
				// short-circuits on the sentinel year before ChoosePaymentDate
				// (INTSUTIL.pas:1026), so it returns no error and the row is
				// TRUNCATED by the summation walks instead. That asymmetry is
				// DOS's, not a choice.
				if err != nil {
					if errors.Is(err, dateutil.ErrJulianCeiling) {
						res.Err = julianCeilingRefusal(saveTo, b.PerYr, j+1)
						return res
					}
					res.Err = err
					return res
				}
				b.setRawTo(ty, tm, td)
				if dateutil.DateComp(saveTo, b.ToDate) != 0 {
					b.ToDateStatus = types.InOutDefault
				}
				// DOS's second FirstPass re-applies the check to the snapped date.
				outOfOrder = dateutil.DateComp(b.FromDate, b.ToDate) >= 0
			}
			if outOfOrder {
				res.Err = fmt.Errorf(
					"the dates are out of order on periodic payment line %d: the From Date must come before the To Date. Swap the two dates, or check the \"Yr to divide century\" setting if a two-digit year landed in the wrong century",
					j+1)
				return res
			}
		}

		// Periodic classification (PRESVALU.pas:594-629). The row is
		// fully_specified when From + To + Amount are all present
		// (forward computes Value). When Value is present and exactly
		// one of {From, To, Amount} is missing, the row is
		// contains_unknown — the row-level backward path solves the
		// missing field (PV-4 / PV-5 / PV-6). Otherwise the row is
		// underspecified.
		hasFrom := b.FromDateStatus >= types.InOutDefault
		hasTo := b.ToDateStatus >= types.InOutDefault
		hasAmt := b.AmtStatus >= types.InOutDefault
		hasVal := b.ValStatus >= types.InOutDefault
		coreCount := 0
		if hasFrom {
			coreCount++
		}
		if hasTo {
			coreCount++
		}
		if hasAmt {
			coreCount++
		}
		var status byte
		switch coreCount {
		case 3:
			// Full forward inputs. If Value is also given, the row is
			// over-specified — surface a soft warning (DOS
			// PRESVALU.pas:1166-1189) and proceed.
			status = types.LineFullySpecified
			if hasVal {
				res.Warnings = append(res.Warnings, fmt.Sprintf(
					"periodic payment row %d is over-specified - the supplied "+
						"Value is redundant and will be recomputed from the "+
						"dates and amount", j+1))
			}
		case 2:
			// From+To+Value is fully_specified — the per-payment Amount is
			// derived from the Value (Amount := Value / summationFactor), the
			// periodic analogue of a Date+Value lump. The other 2-core shapes
			// (From+Amount or To+Amount) stay contains_unknown: with a Value they
			// are row-level To/From solves; without one they are the
			// screen-residual unknown. Treating From+To+Value as an unknown let it
			// steal backward dispatch on a multi-row screen (discrepancies.md §26).
			if hasVal && hasFrom && hasTo {
				status = types.LineFullySpecified
			} else {
				status = types.LineContainsUnknown
			}
		case 1, 0:
			// Two or more of the core inputs missing — not enough
			// data even with Value present. Fall through with the
			// decremented status so the existing missing-2 / missing-3
			// flags drive the same error messages.
			status = types.LineFullySpecified
			if !hasFrom {
				status--
			}
			if !hasTo {
				status--
			}
			if !hasAmt && !hasVal {
				status--
			}
		}
		if b.PerYrStatus < types.InOutDefault {
			// peryr missing -> step down by 4 (DOS: dec(b[j]^.status,4))
			if status >= 4 {
				status -= 4
			} else {
				// (coverage: excluded — defensive/unreachable: the switch
				// above only assigns LineMissing4..LineFullySpecified
				// (250..254), all >= 4, so status is never below 4 here.)
				status = types.LineMissing4
			}
		}
		// C-P-2/3 (periodic): a contains_unknown row with amt=0 or
		// val=0 can't be solved (divides by the supplied field).
		// Status here is between LineMissing4 and LineFullySpecified;
		// LineContainsUnknown is the case we care about.
		if status == types.LineContainsUnknown {
			if b.AmtStatus >= types.InOutDefault && b.Amt == 0 {
				res.Err = fmt.Errorf("the amount cannot be zero on periodic payment "+
					"line %d when it is the only field given — Per%%Sense would have "+
					"nothing to solve from. Enter a non-zero Amount, or fill in "+
					"the dates and Value and leave the Amount blank to solve for it",
					j+1)
				return res
			}
			if b.ValStatus >= types.InOutDefault && b.Val == 0 {
				res.Err = fmt.Errorf("the value cannot be zero on periodic payment "+
					"line %d when it is the only field given — Per%%Sense would have "+
					"nothing to solve from. Enter a non-zero Value, or fill in "+
					"the dates and Amount and leave the Value blank to solve for it",
					j+1)
				return res
			}
		}
		res.PeriodicStatus[j] = status
		b.Status = int(status)
	}

	// BLOCK 1 - LumpSum block. Each row is fully_specified when it has
	// Date AND Amount (forward computes Value); contains_unknown when
	// exactly one of {Date, Amount} is missing and a target Value is
	// supplied (PV-1 / PV-2); else blank or contains_unknown.
	// PRESVALU.pas inlines this into ComputeLumpsumLineValues.
	for i := range input.LumpSums {
		a := &input.LumpSums[i]
		hasDate := a.DateStatus >= types.InOutDefault
		hasAmt := a.AmtStatus >= types.InOutDefault
		hasVal := a.ValStatus >= types.InOutDefault
		nFields := 0
		if hasDate {
			nFields++
		}
		if hasAmt {
			nFields++
		}
		if hasVal {
			nFields++
		}
		var status byte
		switch nFields {
		case 0:
			status = types.LineBlank
		case 1:
			// C-P-2 / C-P-3: a contains_unknown row with only
			// amt=0 or only val=0 cannot be solved (the supplied
			// field is the divisor in the back-solve). DOS
			// PRESVALU.pas: ComputeLumpsumLineValues records this
			// as RecordError(amountcol/valuecol).
			if a.AmtStatus >= types.InOutDefault && a.Amt == 0 {
				res.Err = fmt.Errorf("the amount cannot be zero on single payment "+
					"line %d when it is the only field given — Per%%Sense would "+
					"have nothing to solve from. Enter a non-zero Amount, or fill "+
					"in the Date and Value and leave the Amount blank to solve for it",
					i+1)
				return res
			}
			if a.ValStatus >= types.InOutDefault && a.Val == 0 {
				res.Err = fmt.Errorf("the value cannot be zero on single payment "+
					"line %d when it is the only field given — Per%%Sense would "+
					"have nothing to solve from. Enter a non-zero Value, or fill "+
					"in the Date and Amount and leave the Value blank to solve for it",
					i+1)
				return res
			}
			status = types.LineContainsUnknown
		case 2:
			// DOS ComputeLumpsumLineValues (PRESVALU.pas:174-178): Date+Amount
			// AND Date+Value are fully_specified — a Date+Value row's face Amount
			// is DERIVED from its Value (amt0 := val0·exxp(-r·YearsDif)), not
			// solved from the screen residual. Only Amount+Value (no Date) stays
			// contains_unknown here — its Date is found by the row-level solver
			// (PRESVALU.pas:225-231). Classifying Date+Value as contains_unknown
			// let a value-bearing "known" row steal backward dispatch from the
			// genuine single-field unknown on a multi-row screen (discrepancies.md §26).
			if hasDate {
				status = types.LineFullySpecified
			} else {
				status = types.LineContainsUnknown
			}
		default:
			// Lump sum row over-specified — date+amt+val all present.
			// Soft warning, not a hard error: DOS PRESVALU.pas:1166-1189
			// records a cancelable warning ("value already determined
			// by data above") and proceeds, treating the row as fully
			// specified from the date + amount and recomputing the
			// redundant Value. See dispatch_gaps §4.7 PV-warning.
			res.Warnings = append(res.Warnings, fmt.Sprintf(
				"single payment row %d is over-specified - the supplied "+
					"Value is redundant and will be recomputed from the "+
					"date and amount", i+1))
			status = types.LineFullySpecified
		}
		res.LumpSumStatus[i] = status
		a.Status = int(status)
	}

	// BLOCK 3 - PresVal line classification.
	// fully_specified = rate + asof + sumvalue.
	// missing one of those is contains_unknown.
	pvFields := 0
	if pv.R.Status > types.StatusEmpty {
		pvFields++
	}
	if pv.AsOfStatus >= types.InOutDefault {
		pvFields++
	}
	if pv.SumValueStatus >= types.InOutDefault {
		pvFields++
	}
	switch pvFields {
	case 0, 1:
		pv.Status = int(types.LineMissing2) // not enough on its own
	case 2:
		pv.Status = int(types.LineContainsUnknown)
	case 3:
		pv.Status = int(types.LineFullySpecified)
	}

	// Determine frontward / backward dispatch.
	// Frontward: rate + asof known AND every populated row is fully_specified.
	if pv.R.Status > types.StatusEmpty && pv.AsOfStatus >= types.InOutDefault {
		res.Frontward = true
		for i := range input.LumpSums {
			s := res.LumpSumStatus[i]
			if s == types.LineContainsUnknown ||
				(s != types.LineBlank && s < types.LineFullySpecified) {
				res.Frontward = false
				break
			}
		}
		if res.Frontward {
			for j := range input.Periodics {
				s := res.PeriodicStatus[j]
				if s == types.LineContainsUnknown ||
					(s != types.LineBlank && s < types.LineFullySpecified) {
					res.Frontward = false
					break
				}
			}
		}
	}

	// Backward dispatch. There are two ways a row-level backward can
	// fire — either a screen-level Sum Value is given (DOS PV-8 / PV-9
	// where the missing row is whatever residual makes the screen
	// total balance), or an individual row supplies its own target
	// Value and is missing one of {Date, Amount} for lumps or one of
	// {From, To, Amount} for periodics (DOS PV-1 / PV-2 / PV-4 / PV-5
	// / PV-6, where the row's own Value is the target).
	hasSumValue := pv.SumValueStatus >= types.InOutDefault
	rowLevelTarget := func() bool {
		if hasSumValue {
			return true
		}
		for i := range input.LumpSums {
			if res.LumpSumStatus[i] == types.LineContainsUnknown &&
				input.LumpSums[i].ValStatus >= types.InOutDefault {
				return true
			}
		}
		for j := range input.Periodics {
			if res.PeriodicStatus[j] == types.LineContainsUnknown &&
				input.Periodics[j].ValStatus >= types.InOutDefault {
				return true
			}
		}
		return false
	}()
	if rowLevelTarget {
		// Case A: a lump-sum or periodic row contains exactly one unknown.
		//   PRESVALU.pas:865 (lumpsum) and :939 (periodic).
		for i := range input.LumpSums {
			if res.LumpSumStatus[i] == types.LineContainsUnknown {
				a := &input.LumpSums[i]
				if a.DateStatus >= types.InOutDefault {
					res.Backward = true
					res.BackwardKind = BackwardLumpAmount
					res.BackwardIndex = i
					return res
				}
				if a.AmtStatus >= types.InOutDefault {
					res.Backward = true
					res.BackwardKind = BackwardLumpDate
					res.BackwardIndex = i
					return res
				}
				// only ValStatus set: insufficient data.
				res.Err = fmt.Errorf(
					"single payment line %d has only a Value filled in, which is not "+
						"enough to solve. Add either the Date or the Amount: with the "+
						"Amount, Per%%Sense solves for the Date; with the Date, it "+
						"solves for the Amount",
					i+1)
				return res
			}
		}
		for j := range input.Periodics {
			if res.PeriodicStatus[j] == types.LineContainsUnknown {
				b := &input.Periodics[j]
				bothDates := b.FromDateStatus >= types.InOutDefault &&
					b.ToDateStatus >= types.InOutDefault
				oneDate := b.FromDateStatus >= types.InOutDefault ||
					b.ToDateStatus >= types.InOutDefault
				if bothDates {
					res.Backward = true
					res.BackwardKind = BackwardPeriodicAmount
					res.BackwardIndex = j
					return res
				}
				if oneDate && b.AmtStatus >= types.InOutDefault {
					res.Backward = true
					res.BackwardIndex = j
					if b.ToDateStatus < types.InOutDefault {
						res.BackwardKind = BackwardPeriodicToDate
					} else {
						res.BackwardKind = BackwardPeriodicFrom
					}
					return res
				}
				res.Err = fmt.Errorf(
					"periodic payment line %d does not have enough filled in to solve. "+
						"Per%%Sense can solve for one missing field only: fill in the "+
						"Amount plus one date (From Date or To Date) and it solves for "+
						"the other date, or fill in both dates and leave the Amount "+
						"blank to solve for the Amount",
					j+1)
				return res
			}
		}
		// Cases B / C only apply when the screen Sum Value is given —
		// PV-8 and PV-9 solve the rate / as-of date that makes the
		// screen total match SumValue. Per-row Value targets don't
		// drive a screen-level rate/asof solve.
		if hasSumValue {
			// Case B: rate is missing but rows are fully specified -> PV-8.
			if pv.R.Status <= types.StatusEmpty &&
				pv.AsOfStatus >= types.InOutDefault {
				res.Backward = true
				res.BackwardKind = BackwardRate
				return res
			}
			// Case C: asof is missing but rate and rows are fully specified -> PV-9.
			if pv.AsOfStatus < types.InOutDefault &&
				pv.R.Status > types.StatusEmpty {
				res.Backward = true
				res.BackwardKind = BackwardAsOf
				return res
			}
		}
	}

	return res
}

// BackwardCalc dispatches to the appropriate solver based on FirstPass
// classification. Caller supplies the FirstPass result (or it'll be
// computed if nil).
//
// Ported from legacy/src/dos_source/PRESVALU.pas: procedure BackwardCalc
// (and the rate/asof solver branches inside FrontwardCalc).
func BackwardCalc(input PVInput, fp *FirstPassResult) PVResult {
	var result PVResult
	if fp == nil {
		fpVal := FirstPass(&input)
		fp = &fpVal
	}
	if fp.Err != nil {
		result.Err = fp.Err
		return result
	}
	if !fp.Backward {
		result.Err = fmt.Errorf("there is not enough information on the screen to solve for the missing field. Supply the target Present Value, and leave exactly one field blank — the one you want Per%%Sense to compute")
		return result
	}

	// Copy input rows into the result so solvers can mutate in place.
	result.LumpSums = append(result.LumpSums, input.LumpSums...)
	result.Periodics = append(result.Periodics, input.Periodics...)

	switch fp.BackwardKind {
	case BackwardLumpAmount:
		solveLumpAmount(&input, &result, fp.BackwardIndex)
	case BackwardLumpDate:
		solveLumpDate(&input, &result, fp.BackwardIndex)
	case BackwardPeriodicAmount:
		solvePeriodicAmount(&input, &result, fp.BackwardIndex)
	case BackwardPeriodicToDate:
		solvePeriodicDate(&input, &result, fp.BackwardIndex, true)
	case BackwardPeriodicFrom:
		solvePeriodicDate(&input, &result, fp.BackwardIndex, false)
	case BackwardRate:
		solveRate(&input, &result)
	case BackwardAsOf:
		solveAsOf(&input, &result)
	default:
		result.Err = fmt.Errorf("unknown backward solve kind")
	}
	// Echo the rate and as-of date actually used. The rate / as-of
	// solvers mutate input.PresVal in place, so for PV-8 and PV-9 this
	// carries the solved value back to the caller.
	result.Rate = input.PresVal.R.Rate
	result.AsOf = input.PresVal.AsOf

	// DOS Enter always runs FrontwardCalc AFTER BackwardCalc
	// (PRESVALU.pas:1253, `for i := nlines downto stopat do FrontwardCalc(i)`),
	// which re-sums the rows into the screen's sumvalue. When the solve target
	// came from a ROW's Value cell (screen Sum Value blank — the PV-2/PV-5/PV-6
	// date solves), the solvers here echoed PresVal.SumValue = 0, so the screen
	// total read $0.00 and even tripped the bogus P-W7 "payments net to about
	// zero" advisory. Complete the DOS flow: the solvers have already written
	// every row's Val (computeKnownRowSum for the known rows, the solved row by
	// its own solver), so the DOS-faithful total is their sum. Found by the
	// 2026-07-24 UI-vs-oracle differential run (PV-S-02/04/05).
	if result.Err == nil && input.PresVal.SumValueStatus < types.InOutDefault {
		var sum float64
		for i := range result.LumpSums {
			sum += result.LumpSums[i].Val
		}
		for i := range result.Periodics {
			sum += result.Periodics[i].Val
		}
		result.SumValue = sum
	}
	return result
}

// computeKnownRowSum walks lump-sum and periodic rows and sums the
// values for those that are fully_specified, computing each value
// where needed. The unknown row at unknownIdx (lump or periodic per
// isLumpSum) is excluded.
//
// Each known row's computed present value is written back into the
// corresponding result row's Val field (as InOutOutput) so the
// response echoes the same per-row values the forward path reports.
// Without this the known rows in a backward solve report a Val of 0
// even though they contribute to the target — a display-only gap, but
// a confusing one. The solved row is left untouched (its own solver
// fills Val). result may be nil when callers only need the sum.
//
// Returns the partial sum subtracted from the target SumValue.
//
// Ported from legacy/src/dos_source/PRESVALU.pas:852-862 (the loops
// at the top of BackwardCalc).
func computeKnownRowSum(input *PVInput, result *PVResult, isLumpSum bool, unknownIdx int) (float64, error) {
	rate := input.PresVal.R.Rate
	asof := input.PresVal.AsOf
	settings := &input.Settings

	var sum float64
	for i := range input.LumpSums {
		ls := &input.LumpSums[i]
		if isLumpSum && i == unknownIdx {
			continue
		}
		hasDate := ls.DateStatus >= types.InOutDefault
		hasAmt := ls.AmtStatus >= types.InOutDefault
		hasVal := ls.ValStatus >= types.InOutDefault
		// A fully_specified lump (Date + Amount OR Value) is a KNOWN contributor:
		// its present value is subtracted from the screen target before solving
		// the genuine unknown. A Date+Value row contributes its Value and its
		// face Amount is derived (DOS ComputeLumpsumLineValues, PRESVALU.pas:210-224).
		if !hasDate || (!hasAmt && !hasVal) {
			continue
		}
		v, err := valueFullySpecifiedLump(ls, asof, rate, settings, input.Actuarial)
		if err != nil {
			return 0, err
		}
		sum += v
		if result != nil && i < len(result.LumpSums) {
			result.LumpSums[i].Val = ls.Val
			result.LumpSums[i].ValStatus = ls.ValStatus
			result.LumpSums[i].Amt = ls.Amt
			result.LumpSums[i].AmtStatus = ls.AmtStatus
			result.LumpSums[i].Prob = ls.Prob
		}
	}
	for j := range input.Periodics {
		pp := &input.Periodics[j]
		if !isLumpSum && j == unknownIdx {
			continue
		}
		hasAmt := pp.AmtStatus >= types.InOutDefault
		hasVal := pp.ValStatus >= types.InOutDefault
		// From+To plus Amount OR Value is a KNOWN periodic contributor; a
		// From+To+Value row contributes its Value and its per-payment Amount
		// is derived (periodic analogue of the Date+Value lump above).
		if pp.FromDateStatus < types.InOutDefault ||
			pp.ToDateStatus < types.InOutDefault ||
			(!hasAmt && !hasVal) {
			continue
		}
		v, err := valueFullySpecifiedPeriodic(pp, asof, rate, settings, input.Actuarial)
		if err != nil {
			return 0, err
		}
		sum += v
		if result != nil && j < len(result.Periodics) {
			result.Periodics[j].Val = pp.Val
			result.Periodics[j].ValStatus = pp.ValStatus
			result.Periodics[j].Amt = pp.Amt
			result.Periodics[j].AmtStatus = pp.AmtStatus
			result.Periodics[j].Prob = pp.Prob
		}
	}
	// Payment-on-death folds into the screen total on the forward path
	// (calc.go) and DOS subtracts it from the backward target when
	// life-contingency is active (PRESVALU.pas:848-849: val := val -
	// PODValue). evaluatePVAt (the rate / as-of solvers) already includes
	// it; the row-level solvers (lump / periodic amount & date) must too,
	// or a configured POD silently fails to balance the solved field.
	if input.Actuarial != nil && input.Actuarial.POD != 0 {
		sum += input.Actuarial.PODValue(asof, rate)
	}
	return sum, nil
}

// solveLumpAmount handles PV-1: lump-sum row has date and value, solve
// for amount = value * exp(rate * yearsDif(date, asof)).
//
// Ported from legacy/src/dos_source/PRESVALU.pas:866-891.
func solveLumpAmount(input *PVInput, result *PVResult, idx int) {
	rate := input.PresVal.R.Rate
	asof := input.PresVal.AsOf
	settings := &input.Settings

	known, err := computeKnownRowSum(input, result, true, idx)
	if err != nil {
		result.Err = err
		return
	}
	target := input.PresVal.SumValue - known

	ls := &result.LumpSums[idx]
	// In DOS, "value" of an unknown row is the residual sumvalue; here we
	// treat user-supplied ls.Val as the row's value if present, else the
	// implied residual.
	rowValue := target
	if ls.ValStatus >= types.InOutDefault {
		rowValue = ls.Val
	}
	years := dateutil.YearsDif(ls.Date, asof, settings.Basis, settings.YrInv, false)
	exprt, err := interest.Exxp(rate * years)
	if err != nil {
		result.Err = err
		return
	}
	ls.Amt = rowValue * exprt
	// Life-contingent row: the forward path scales the value by the
	// survival probability, so solving the amount divides it back out
	// (DOS PRESVALU.pas:873-883). When that probability is effectively
	// zero — the payment is dated so far out that survival is
	// impossible per the life table — the division blows up and there
	// is no meaningful amount to report. DOS errors here ("date of lump
	// sum payment N is beyond life span"); match that rather than
	// silently returning an un-adjusted (and wrong) amount.
	if input.Actuarial != nil && ls.Act != actuarial.NotContingent {
		prob := input.Actuarial.LifeProb(ls.Date, ls.Act)
		if prob <= types.Teeny {
			result.Err = fmt.Errorf(
				"single payment line %d is a life-contingency payment dated beyond "+
					"the life table's horizon — the survival probability is "+
					"effectively zero, so the Amount cannot be solved (the value would "+
					"be divided by a probability of zero). Use an earlier Date, or "+
					"check the Date of Birth and life-table settings.", idx+1)
			return
		}
		ls.Amt /= prob
	}
	ls.AmtStatus = types.InOutOutput
	ls.Val = rowValue
	ls.ValStatus = types.InOutOutput
	result.SumValue = input.PresVal.SumValue
}

// solveLumpDate handles PV-2: lump-sum row has amount and value, solve
// for the date via Newton-Raphson on yrs = ln(value/amount)/rate, then
// AddYears.
//
// Iteration mirrors PRESVALU.pas:892-931:
//   - guard against opposite signs (value/amount sign mismatch)
//   - guess starts at asof, count <= 30
//   - convergence: |diff| < 0.003 (one day)
//   - cap diff in (-20, 20) years per step
//
// Ported from legacy/src/dos_source/PRESVALU.pas:892-931.
func solveLumpDate(input *PVInput, result *PVResult, idx int) {
	rate := input.PresVal.R.Rate
	asof := input.PresVal.AsOf
	settings := &input.Settings

	if math.Abs(rate) < types.Teeny {
		result.Err = fmt.Errorf(
			"cannot solve for the Date on single payment line %d because the Rate "+
				"is too small (at or near zero): with no interest, the Amount and "+
				"Value are equal at every date, so the Date is undetermined. Enter a "+
				"non-zero Rate, or fill in the Date and leave the Amount blank instead",
			idx+1)
		return
	}

	// A life-contingent row cannot have its date solved: the survival
	// probability is itself a function of the unknown date, so the
	// equation is not invertible. DOS rejects this outright with
	// "no_time_with_life" (PRESVALU.pas:894-897).
	if input.Actuarial != nil && idx < len(input.LumpSums) &&
		input.LumpSums[idx].Act != actuarial.NotContingent {
		result.Err = fmt.Errorf(
			"cannot solve for the Date on single payment line %d because it is a "+
				"life-contingency payment: the survival probability itself depends "+
				"on the date, so the date cannot be worked out from the Value. Fill "+
				"in the Date and leave the Amount blank to solve for the Amount instead",
			idx+1)
		return
	}

	known, err := computeKnownRowSum(input, result, true, idx)
	if err != nil {
		result.Err = err
		return
	}
	rowValue := input.PresVal.SumValue - known
	ls := &result.LumpSums[idx]
	if ls.ValStatus >= types.InOutDefault {
		rowValue = ls.Val
	}

	if (rowValue > 0) != (ls.Amt > 0) {
		result.Err = fmt.Errorf(
			"the Value and the Amount on single payment line %d have opposite "+
				"signs, so no date can make them consistent — discounting can "+
				"shrink or grow a payment but cannot flip it from positive to "+
				"negative. Make the Value and Amount both positive (or both "+
				"negative) so they agree in sign",
			idx+1)
		return
	}

	// First guess: payment occurs at asof.
	wdate := asof
	count := 0
	for {
		count++
		if count > 30 {
			result.Err = fmt.Errorf(
				`the "date" computation for single payment line %d did not converge `+
					`on an answer. The Value may be unreachable for this Amount and `+
					`Rate — check that the Value and Amount are sensible, or fill in `+
					`the Date and leave the Amount blank to solve for the Amount instead`,
				idx+1)
			return
		}
		yrs := dateutil.YearsDif(asof, wdate, settings.Basis, settings.YrInv, false)
		exprt, err := interest.Exxp(rate * yrs)
		if err != nil {
			result.Err = err
			return
		}
		val := ls.Amt * exprt
		dval := ls.Amt * rate * exprt
		if math.Abs(dval) < types.Teeny {
			result.Err = fmt.Errorf(
				"the Date computation for single payment line %d could not proceed "+
					"because the calculation stalled (the Amount or Rate gives no "+
					"sensitivity to move the date). Check that the Amount and Rate "+
					"are non-zero and sensible, or fill in the Date and solve for "+
					"the Amount instead",
				idx+1)
			return
		}
		diff := (rowValue - val) / dval
		if diff > 20 {
			diff = 20
		} else if diff < -20 {
			diff = -20
		}
		wdate, err = dateutil.AddYears(wdate, -diff, settings.Basis, settings.YrDays)
		if err != nil {
			result.Err = err
			return
		}
		// DOS aborts the date search when the iterate leaves its representable
		// window (PRESVALU.pas:915 `if (wdate.y>199) then count:=30`, which then
		// exits the loop into the non-converge branch). The daterec year is stored
		// as (year-1900) in a word, so `y>199` catches year>2099 AND, via word-wrap
		// of a negative, year<1900 — i.e. the date must stay within [1900, 2099].
		// This wins over the |diff|<0.003 convergence test below (DOS sets
		// count:=30 before the `until` check), so an out-of-range iterate is a
		// refusal even if the step looked converged. Without this, the port's
		// Newton happily converges to nonsensical dates (e.g. 1596 or 2351) for an
		// unreachable Value where DOS reports non-convergence. 2026-07-16 PV fuzzer3.
		if y := wdate.Time.Year(); y < 1900 || y > 2099 {
			result.Err = fmt.Errorf(
				`the "date" computation for single payment line %d did not converge `+
					`on an answer. The Value may be unreachable for this Amount and `+
					`Rate — check that the Value and Amount are sensible, or fill in `+
					`the Date and leave the Amount blank to solve for the Amount instead`,
				idx+1)
			return
		}
		if math.Abs(diff) < 0.003 {
			break
		}
	}

	ls.Date = wdate
	ls.DateStatus = types.InOutOutput
	ls.Val = rowValue
	ls.ValStatus = types.InOutOutput
	result.SumValue = input.PresVal.SumValue
}

// solvePeriodicAmount handles PV-4: periodic row has both dates and
// value, solve for amount = value / Summation.
//
// Ported from legacy/src/dos_source/PRESVALU.pas:943-956.
func solvePeriodicAmount(input *PVInput, result *PVResult, idx int) {
	rate := input.PresVal.R.Rate
	asof := input.PresVal.AsOf
	settings := &input.Settings

	known, err := computeKnownRowSum(input, result, false, idx)
	if err != nil {
		result.Err = err
		return
	}
	rowValue := input.PresVal.SumValue - known

	pp := &result.Periodics[idx]
	if pp.ValStatus >= types.InOutDefault {
		rowValue = pp.Val
	}

	cola := pp.COLA
	if pp.COLAStatus < types.InOutDefault {
		cola = 0
	}
	nInst := pp.NInstallments
	if nInst <= 0 {
		nInst = estimateInstallments(pp.FromDate, pp.ToDate, pp.PerYr)
		pp.NInstallments = nInst
	}
	// The forward path weights each installment by the survival
	// probability when the row is life-contingent. DOS does the same:
	// amtn := valn/Summation(1,j), and Summation folds in LifeProb when
	// fold_in_life is set (PRESVALU.pas:397, :949). Divide by the SAME
	// survival-weighted summation, or the solved amount comes out short
	// by the average survival factor.
	factor, err := weightedPeriodicFactor(input, pp, pp.FromDate, pp.ToDate,
		asof, rate, cola, nInst, settings)
	if err != nil {
		result.Err = err
		return
	}
	if math.Abs(factor) < types.Teeny {
		result.Err = fmt.Errorf(
			"cannot solve for the Amount on periodic payment line %d: the present "+
				"value of the payment stream works out to essentially zero, so "+
				"dividing the target Value by it gives no answer. Check the From "+
				"Date, To Date, Pmts-Yr and Rate on that row",
			idx+1)
		return
	}
	pp.Amt = rowValue / factor
	pp.AmtStatus = types.InOutOutput
	pp.Val = rowValue
	pp.ValStatus = types.InOutOutput
	result.SumValue = input.PresVal.SumValue
}

// solvePeriodicDate handles PV-5 (toDate unknown) and PV-6 (fromDate
// unknown). Uses the closed-form approximation
//
//	yrs = (-1/(r-cola)) * ln( first ) ;  fromDate via similar derivation
//
// then refines by stepping ±1 period until error stops decreasing.
//
// PV-5: PRESVALU.pas:965-999.
// PV-6: PRESVALU.pas:1000-1070.
//
// The DOS {$ifdef V_3} const_signal block is intentionally not
// reproduced — V_3 is never defined in the authoritative DOS build,
// so that block is dead code (see docs/dispatch_gaps.md §0.5.5).
//
// The cola != 0 second approximation (PRESVALU.pas:1029-1035) IS
// implemented for the from-date solve, followed by the ±1 period
// refinement loop.
func solvePeriodicDate(input *PVInput, result *PVResult, idx int, solveTo bool) {
	rate := input.PresVal.R.Rate
	asof := input.PresVal.AsOf
	settings := &input.Settings

	known, err := computeKnownRowSum(input, result, false, idx)
	if err != nil {
		result.Err = err
		return
	}
	target := input.PresVal.SumValue - known
	pp := &result.Periodics[idx]
	if pp.ValStatus >= types.InOutDefault {
		target = pp.Val
	}

	if (target > 0) != (pp.Amt > 0) {
		result.Err = fmt.Errorf(
			"the Value and the Amount on periodic payment line %d have opposite "+
				"signs, so no From/To Date can make them agree — a stream of "+
				"positive payments cannot have a negative present value. Make the "+
				"Value and Amount both positive (or both negative) so they match "+
				"in sign",
			idx+1)
		return
	}

	cola := pp.COLA
	if pp.COLAStatus < types.InOutDefault {
		cola = 0
	}
	rpy := interest.RealPerYr(byte(pp.PerYr), settings.YrDays)
	f, err := interest.Exxp((cola - rate) / rpy)
	if err != nil {
		result.Err = err
		return
	}

	if solveTo {
		// PV-5: solve for toDate.
		first, err := interest.Exxp(rate * dateutil.YearsDif(asof, pp.FromDate,
			settings.Basis, settings.YrInv, false))
		if err != nil {
			result.Err = err
			return
		}
		last := (first - (1-f)*target/pp.Amt) / f
		toDate := pp.FromDate
		if math.Abs(rate-cola) < types.Teeny {
			n := int(math.Round(target / pp.Amt))
			toDate, err = dateutil.AddNPeriods(pp.FromDate, pp.PerYr, n)
		} else {
			lnLast, lerr := interest.Lnn(last * f / first)
			if lerr != nil {
				err = lerr
			} else {
				// PRESVALU.pas:970 — note the leading minus sign:
				//   AddYears(todate, -(lnn(last*f/first)/(r.rate-cola) + 1/RealPerYr(peryr)))
				yrs := -(lnLast/(rate-cola) + 1.0/rpy)
				toDate, err = dateutil.AddYears(toDate, yrs, settings.Basis, settings.YrDays)
			}
		}
		if err != nil {
			result.Err = err
			return
		}
		pp.ToDate = refinePeriodicDate(input, pp, idx, toDate, target, true, settings)
		pp.ToDateStatus = types.InOutOutput
	} else {
		// PV-6: solve for fromDate.
		// First approximation - if toDate is "latest", use simpler form.
		latest := types.LatestDate()
		var fromDate types.DateRec
		if pp.ToDate.Time.Equal(latest.Time) {
			firstTerm := (1 - f) * target / pp.Amt
			lnFirst, lerr := interest.Lnn(firstTerm)
			if lerr != nil {
				result.Err = lerr
				return
			}
			yrs := (-1.0 / (rate - cola)) * lnFirst
			fromDate, err = dateutil.AddYears(asof, yrs, settings.Basis, settings.YrDays)
			if err != nil {
				result.Err = err
				return
			}
		} else {
			last, err := interest.Exxp((rate - cola) * dateutil.YearsDif(asof, pp.ToDate,
				settings.Basis, settings.YrInv, false))
			if err != nil {
				result.Err = err
				return
			}
			firstTerm := f*last + (1-f)*target/pp.Amt
			if firstTerm <= 0 || math.Abs(rate-cola) < types.Teeny {
				// PUNT path - PRESVALU.pas:1020 - rare case where cola>rate.
				// Fall back to toDate as the starting point.
				fromDate = pp.ToDate
			} else {
				lnRatio, err := interest.Lnn(last * f / firstTerm)
				if err != nil {
					result.Err = err
					return
				}
				fromDate = pp.ToDate
				fromDate, err = dateutil.AddYears(fromDate,
					lnRatio/(rate-cola)+1.0/rpy, settings.Basis, settings.YrDays)
				if err != nil {
					result.Err = err
					return
				}
			}
		}
		// Second approximation (PRESVALU.pas:1029-1035): with a
		// non-zero COLA the discount factor changes at fromDate — the
		// rate applies asof->fromDate and (rate-cola) applies
		// fromDate->toDate. Refine the first estimate accordingly.
		if cola != 0 && math.Abs(rate-cola) >= types.Teeny {
			lA, e1 := interest.Exxp(rate * dateutil.YearsDif(asof, fromDate,
				settings.Basis, settings.YrInv, false))
			lB, e2 := interest.Exxp((rate - cola) * dateutil.YearsDif(fromDate, pp.ToDate,
				settings.Basis, settings.YrInv, false))
			if e1 == nil && e2 == nil {
				last2 := lA * lB
				first2 := f*last2 + (1-f)*target/pp.Amt
				if first2 > 0 {
					if lnRatio2, e3 := interest.Lnn(last2 * f / first2); e3 == nil {
						if nfd, e4 := dateutil.AddYears(pp.ToDate,
							lnRatio2/(rate-cola)+1.0/rpy, settings.Basis,
							settings.YrDays); e4 == nil {
							fromDate = nfd
						}
					}
				}
			}
		}
		pp.FromDate = refinePeriodicDate(input, pp, idx, fromDate, target, false, settings)
		pp.FromDateStatus = types.InOutOutput
	}

	// Final amount correction within 1 cent (PRESVALU.pas:1072-1078).
	cola = pp.COLA
	if pp.COLAStatus < types.InOutDefault {
		cola = 0
	}
	pp.NInstallments = estimateInstallments(pp.FromDate, pp.ToDate, pp.PerYr)
	factor, err := weightedPeriodicFactor(input, pp, pp.FromDate, pp.ToDate,
		asof, rate, cola, pp.NInstallments, settings)
	if err != nil {
		result.Err = err
		return
	}
	valn := pp.Amt * factor
	if math.Abs(valn) > types.Small {
		corAmt := pp.Amt * (target / valn)
		if math.Abs(corAmt-pp.Amt) > 0.01 {
			pp.Amt = corAmt
			pp.AmtStatus = types.InOutDefault
			valn = target
		}
	}
	pp.Val = valn
	pp.ValStatus = types.InOutOutput
	result.SumValue = input.PresVal.SumValue
}

// refinePeriodicDate steps the candidate date ±1 period at a time until
// the resulting periodic value moves *away* from the target, then backs
// off by one. Mirrors the "alternate try" loops in PRESVALU.pas:976-987
// and 1047-1062.
func refinePeriodicDate(input *PVInput, pp *PeriodicPayment, idx int,
	candidate types.DateRec, target float64, solveTo bool, settings *PVSettings) types.DateRec {

	rate := input.PresVal.R.Rate
	asof := input.PresVal.AsOf
	cola := pp.COLA
	if pp.COLAStatus < types.InOutDefault {
		cola = 0
	}

	originalTo, originalFrom := pp.ToDate, pp.FromDate

	calc := func(from, to types.DateRec) float64 {
		n := estimateInstallments(from, to, pp.PerYr)
		factor, err := weightedPeriodicFactor(input, pp, from, to, asof, rate, cola, n, settings)
		if err != nil {
			return math.NaN()
		}
		return pp.Amt * factor
	}

	// value(d) is the periodic present value when the solved date is d.
	value := func(d types.DateRec) float64 {
		if solveTo {
			return calc(originalFrom, d)
		}
		return calc(d, originalTo)
	}

	// Step whole periods to bracket the target (DOS behavior). anchorDay
	// keeps the candidate on the payment-period grid while stepping.
	anchorDay := originalFrom.Time.Day()
	if !solveTo {
		anchorDay = candidate.Time.Day()
	}
	best := candidate
	bestVal := value(best)
	var subtract bool
	if solveTo {
		subtract = (target < bestVal) != (pp.Amt < 0)
	} else {
		subtract = (target > bestVal) != (pp.Amt < 0)
	}
	for i := 0; i < 60; i++ {
		next, err := dateutil.AddPeriod(best, pp.PerYr, anchorDay, subtract)
		if err != nil {
			break
		}
		newVal := value(next)
		// (coverage: excluded — defensive/unreachable: value() returns NaN
		// only when weightedPeriodicFactor errors on arithmetic overflow,
		// which the normal date-range candidates here never trigger.)
		if math.IsNaN(newVal) {
			break
		}
		if math.Abs(target-bestVal) < math.Abs(target-newVal) {
			break
		}
		best = next
		bestVal = newVal
	}

	// Day-level refinement. The From Date anchors every installment, so
	// shifting it a few days moves the whole discounted stream — its
	// value varies continuously with the date and can be driven to the
	// target within a day. The To Date solve is a step function (the
	// value only changes as the date crosses an installment boundary),
	// so there is nothing to gain between grid points; refineDateByDays
	// leaves it on the period grid via its sign-change and
	// strict-improvement guards.
	return refineDateByDays(value, best, target, pp.PerYr)
}

// refineDateByDays bisects on the calendar day, within one payment
// period either side of `best`, to drive a solved periodic date's value
// to `target`. It moves off `best` only when the value crosses the
// target continuously across the bracket (a sign change exists) and the
// result is meaningfully closer (more than half a cent). This tightens
// the From Date solve to ~1 day while leaving the step-function To Date
// solve on its period grid.
func refineDateByDays(value func(types.DateRec) float64, best types.DateRec,
	target float64, peryr int) types.DateRec {

	bestErr := math.Abs(target - value(best))
	if bestErr < 0.005 { // already within half a cent of the target
		return best
	}
	// One payment period expressed in calendar days at `best`.
	fwd, err := dateutil.AddPeriod(best, peryr, best.Time.Day(), false)
	if err != nil {
		return best
	}
	periodDays := int(fwd.Time.Sub(best.Time).Hours()/24 + 0.5)
	if periodDays < 2 {
		return best
	}
	lo := types.DateRec{Time: best.Time.AddDate(0, 0, -periodDays)}
	hi := types.DateRec{Time: best.Time.AddDate(0, 0, periodDays)}
	fLo := value(lo) - target
	fHi := value(hi) - target
	if math.IsNaN(fLo) || math.IsNaN(fHi) || (fLo > 0) == (fHi > 0) {
		// No continuous sign change to bisect (e.g. the To Date step
		// function, or a flat region) — keep the grid date.
		return best
	}
	for i := 0; i < 40 && hi.Time.Sub(lo.Time) > 24*time.Hour; i++ {
		mid := types.DateRec{Time: lo.Time.Add(hi.Time.Sub(lo.Time) / 2)}
		fMid := value(mid) - target
		// (coverage: excluded — defensive/unreachable: value() returns NaN
		// only on weightedPeriodicFactor arithmetic overflow; the bracketed
		// midpoints here are bounded dates that never overflow.)
		if math.IsNaN(fMid) {
			break
		}
		if (fMid > 0) == (fLo > 0) {
			lo, fLo = mid, fMid
		} else {
			hi, fHi = mid, fMid
		}
	}
	cand := lo
	if math.Abs(fHi) < math.Abs(fLo) {
		cand = hi
	}
	if bestErr-math.Abs(target-value(cand)) > 0.005 {
		return cand
	}
	return best
}

// solveRate handles PV-8: rate is unknown. A damped Newton (±0.04 per step)
// from a 0.1 seed, restarting once from 0.
//
// Ported from legacy/src/dos_source/PRESVALU.pas:694-747. The DOS restart
// (`goto START_AGAIN_FROM_0`, :707) does NOT reset the byte `count`, so the
// second pass runs a full byte cycle (~256 iterations) before `count` wraps back
// to 30 — enough to reach a high rate that needs many damped ±0.04 steps. The
// earlier port reset count to 0 on each pass, capping the second pass at 30 and
// failing to converge for true rates above ~120% where DOS succeeds (audit B2 /
// discrepancies.md §30). `count` is a uint8 here to reproduce the byte-wrap.
func solveRate(input *PVInput, result *PVResult) {
	asof := input.PresVal.AsOf
	settings := &input.Settings
	target := input.PresVal.SumValue

	rate := 0.1
	secondTime := false
	var oldSum, diff float64
	var count uint8
	for {
		count++ // DOS: inc(count)
		sum, err := evaluatePVAt(input, rate, asof, settings)
		if err != nil {
			result.Err = err
			return
		}
		denom := sum - oldSum
		if math.Abs(denom) < types.Teeny {
			denom = types.Teeny
		}
		if count == 1 {
			diff = 0.001
		} else {
			diff = (target - sum) * diff / denom
		}
		if count == 2 && diff == 0 {
			result.Err = fmt.Errorf(
				"the Rate is not determined by what is on the screen: the payment " +
					"rows give Per%%Sense no way to pin down a single interest rate. " +
					"Enter the Amount on each payment row (rather than only its " +
					"Value), or fill in the Rate directly")
			return
		}
		oldSum = sum
		if diff < -0.04 {
			diff = -0.04
		} else if diff > 0.04 {
			diff = 0.04
		}
		rate = rate - diff

		// DOS: until (abs(diff)<teeny) or (count=30). A count=30 exit is treated
		// as non-convergence (restart or fail) even if diff also went tiny —
		// PRESVALU.pas:736-745 checks `if (count=30)` before the converged path.
		if math.Abs(diff) >= types.Teeny && count != 30 {
			continue
		}
		if count == 30 {
			if secondTime {
				result.Err = fmt.Errorf(`the "rate" computation did not converge ` +
					`on an answer — no single interest rate makes the payments add ` +
					`up to the Present Value you entered. Check that the target ` +
					`Present Value is reachable from the payments, or fill in the ` +
					`Rate and leave the As-of Date or a payment amount blank instead`)
				return
			}
			secondTime = true
			rate = 0
			// count is NOT reset (DOS goto START_AGAIN_FROM_0) — it byte-wraps,
			// giving the second pass ~256 iterations before count=30 recurs.
			continue
		}
		// Converged (diff tiny, count != 30).
		input.PresVal.R.Rate = rate
		input.PresVal.R.Status = types.StatusFromCalc
		*result = frontwardCompute(input)
		return
	}
}

// solveAsOf handles PV-9: as-of date is unknown. PRESVALU.pas:755-818.
//
// Iteration uses asof = asof + ln(target/sum)/rate; converges in ~2
// passes per the DOS comment "doesn't really require iteration".
func solveAsOf(input *PVInput, result *PVResult) {
	rate := input.PresVal.R.Rate
	settings := &input.Settings
	target := input.PresVal.SumValue

	if math.Abs(rate) < types.Teeny {
		result.Err = fmt.Errorf(
			"cannot solve for the As-of Date because the Rate is too small (at or " +
				"near zero): with no interest, the present value is the same at " +
				"every date, so the As-of Date is undetermined. Enter a non-zero " +
				"Rate, or fill in the As-of Date and leave the Rate blank instead")
		return
	}

	// First guess: 2000-01-01, matching the DOS source exactly. DOS seeds the
	// As-of search with `asof.y := 100` (PRESVALU.pas:761), and the daterec
	// year byte is (calendar year - 1900) — see types/records.go and the DOS
	// oracle (asof.y := 124 == 2024). So pascal y=100 is the year 2000, NOT
	// 1900. Starting at 1900 made the first Newton step ~(answer-1900) years,
	// which trips AddYears' 128-year guard (dateutil.go) for any answer >= ~2029,
	// even though DOS — starting at 2000 — solves it in one small step. Using
	// 2000 restores DOS-faithful behavior (boundary moves out to ~2128) and
	// changes no converged result.
	asof := types.NewDateRec(2000, 1, 1)
	maxDate := types.LatestDate()
	converged := false
	for count := 0; count < 10; count++ {
		sum, err := evaluatePVAt(input, rate, asof, settings)
		if err != nil {
			result.Err = err
			return
		}
		if math.Abs(sum) < types.Teeny {
			result.Err = fmt.Errorf(
				"cannot solve for the As-of Date because the payments add up to a " +
					"present value of zero, leaving no date to discount toward. " +
					"Check the payment rows, or fill in the As-of Date and leave " +
					"the Rate blank instead")
			return
		}
		ratio := target / sum
		if ratio <= 0 {
			result.Err = fmt.Errorf(
				"cannot solve for the As-of Date because the target Present Value " +
					"has the opposite sign of the payments — no As-of Date can turn " +
					"a positive set of payments into a negative Present Value. Make " +
					"the Present Value match the sign of the payments")
			return
		}
		ln, err := interest.Lnn(ratio)
		if err != nil {
			result.Err = err
			return
		}
		diff := ln / rate
		newAsof, err := dateutil.AddYears(asof, diff, settings.Basis, settings.YrDays)
		if err != nil {
			result.Err = err
			return
		}
		asof = newAsof
		if math.Abs(diff) < 0.002 {
			converged = true
			break
		}
		if dateutil.DateComp(asof, maxDate) > 0 {
			result.Err = fmt.Errorf(`the "as of" computation did not converge ` +
				`on an answer — no As-of Date gives the Present Value you entered ` +
				`(the date ran past the supported range). Check that the target ` +
				`Present Value is reachable from the payments at this Rate, or fill ` +
				`in the As-of Date and leave the Rate blank instead`)
			return
		}
	}
	// DOS refuses when the search runs the full budget without converging
	// (PRESVALU.pas:806 `if (count=10) … MessageBox('"As of" … did not converge')`)
	// OR when the solved date leaves its representable [1900, 2099] window (the
	// year-1900 word storage; see solveLumpDate). The port previously fell out of
	// the loop and ACCEPTED an un-converged as-of, returning a date for an
	// unreachable target where DOS refuses. 2026-07-16 PV fuzzer3.
	if y := asof.Time.Year(); !converged || y < 1900 || y > 2099 {
		result.Err = fmt.Errorf(`the "as of" computation did not converge ` +
			`on an answer — no As-of Date gives the Present Value you entered. ` +
			`Check that the target Present Value is reachable from the payments ` +
			`at this Rate, or fill in the As-of Date and leave the Rate blank instead`)
		return
	}

	input.PresVal.AsOf = asof
	input.PresVal.AsOfStatus = types.InOutOutput
	*result = frontwardCompute(input)
	result.SumValue = target
}

// evaluatePVAt computes the total present value of all populated rows
// at a candidate (rate, asof) without mutating input. Used by the
// rate and as-of solvers.
func evaluatePVAt(input *PVInput, rate float64, asof types.DateRec,
	settings *PVSettings) (float64, error) {

	var sum float64
	for i := range input.LumpSums {
		ls := &input.LumpSums[i]
		if ls.DateStatus < types.InOutDefault || ls.AmtStatus < types.InOutDefault {
			continue
		}
		v, err := lumpRowPV(ls, asof, rate, settings, input.Actuarial)
		if err != nil {
			return 0, err
		}
		sum += v
	}
	for j := range input.Periodics {
		pp := &input.Periodics[j]
		if pp.FromDateStatus < types.InOutDefault ||
			pp.ToDateStatus < types.InOutDefault ||
			pp.AmtStatus < types.InOutDefault {
			continue
		}
		v, err := periodicRowPV(pp, asof, rate, settings, input.Actuarial)
		if err != nil {
			return 0, err
		}
		sum += v
	}
	// POD (payment-on-death) value folds into the total, matching the
	// forward path (calc.go:392) — DOS PRESVALU.pas:689.
	if input.Actuarial != nil && input.Actuarial.POD != 0 {
		sum += input.Actuarial.PODValue(asof, rate)
	}
	return sum, nil
}

// frontwardCompute is the existing forward path extracted to a helper
// so backward solvers can re-run it once they've nailed down the
// missing input. Mirrors PRESVALU.pas: FrontwardCalc post-solve refresh.
func frontwardCompute(input *PVInput) PVResult {
	// The existing public Calculate runs the forward path when rate +
	// asof are present; reuse it to avoid duplicate logic.
	cp := *input
	cp.PresVal.SumValueStatus = types.StatusEmpty // force recompute
	return forwardOnly(cp)
}
