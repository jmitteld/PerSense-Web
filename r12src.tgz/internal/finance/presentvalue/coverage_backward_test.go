package presentvalue

// Coverage for the backward solver branches (backward.go) that the
// existing suite leaves uncovered: BackwardCalc guards, the rate / as-of
// solver error arms, periodic from-date PUNT/latest paths, and the
// computeKnownRowSum skip/POD branches.

import (
	"strings"
	"testing"
	"time"

	"github.com/persense/persense-port/internal/types"
)

// BackwardCalc with a nil FirstPass result computes one internally
// (backward.go:521). Use a clean PV-1 lump-amount solve.
func TestBackwardCalcNilFirstPass(t *testing.T) {
	in := PVInput{
		Settings: defaultSettings(),
		LumpSums: []LumpSumPayment{{
			DateStatus: types.InOutInput, Date: newDate(2025, time.January, 1),
		}},
		PresVal: PresValLine{
			AsOfStatus: types.InOutInput, AsOf: newDate(2024, time.January, 1),
			R:              RateEntry{Status: types.InOutInput, Rate: 0.06},
			SumValueStatus: types.InOutInput, SumValue: 9000,
		},
	}
	res := BackwardCalc(in, nil)
	if res.Err != nil {
		t.Fatalf("nil-fp backward should solve, got %v", res.Err)
	}
	if res.LumpSums[0].AmtStatus >= types.InOutDefault {
		t.Fatalf("amount should be solved (output status), got %d", res.LumpSums[0].AmtStatus)
	}
}

// BackwardCalc surfaces a FirstPass error (backward.go:525). A periodic
// row with out-of-order dates makes FirstPass error.
func TestBackwardCalcFirstPassError(t *testing.T) {
	in := PVInput{
		Settings: defaultSettings(),
		Periodics: []PeriodicPayment{{
			FromDateStatus: types.InOutInput, FromDate: newDate(2030, time.January, 1),
			ToDateStatus: types.InOutInput, ToDate: newDate(2025, time.January, 1),
			PerYrStatus: types.InOutInput, PerYr: 12,
			AmtStatus: types.InOutInput, Amt: 100,
		}},
		PresVal: PresValLine{
			AsOfStatus: types.InOutInput, AsOf: newDate(2024, time.January, 1),
			R:              RateEntry{Status: types.InOutInput, Rate: 0.06},
			SumValueStatus: types.InOutInput, SumValue: 5000,
		},
	}
	res := BackwardCalc(in, nil)
	if res.Err == nil || !strings.Contains(res.Err.Error(), "out of order") {
		t.Fatalf("expected date-order error, got %v", res.Err)
	}
}

// BackwardCalc with !Backward returns the "not enough information" error
// (backward.go:529-531). Pass a FirstPass result with Backward=false.
func TestBackwardCalcNotBackward(t *testing.T) {
	in := PVInput{Settings: defaultSettings()}
	fp := FirstPassResult{Backward: false}
	res := BackwardCalc(in, &fp)
	if res.Err == nil || !strings.Contains(res.Err.Error(), "not enough information") {
		t.Fatalf("expected not-enough-information error, got %v", res.Err)
	}
}

// BackwardCalc default arm: an unknown BackwardKind (backward.go:553-554).
func TestBackwardCalcUnknownKind(t *testing.T) {
	in := PVInput{Settings: defaultSettings()}
	fp := FirstPassResult{Backward: true, BackwardKind: BackwardKind(99)}
	res := BackwardCalc(in, &fp)
	if res.Err == nil || !strings.Contains(res.Err.Error(), "unknown backward solve kind") {
		t.Fatalf("expected unknown-kind error, got %v", res.Err)
	}
}

// FirstPass periodic contains_unknown with val==0 supplied errors
// (backward.go:267-273).
// A From+To+Value periodic row is fully_specified in DOS (PRESVALU.pas active
// classifier, "NEW 3/31/92": val present cancels amt missing), and the
// zero-value RecordError fires ONLY on a contains_unknown row. So From+To+Value=0
// is NOT an error in DOS — it derives amtn := valn/Summation = 0. The port
// previously misclassified it contains_unknown and errored (a non-DOS behavior
// that also let value-bearing rows steal multi-row backward dispatch —
// discrepancies.md §26).
func TestFirstPassPeriodicZeroValueIsValidZeroRow(t *testing.T) {
	in := PVInput{
		Settings: defaultSettings(),
		Periodics: []PeriodicPayment{{
			FromDateStatus: types.InOutInput, FromDate: newDate(2025, time.January, 1),
			ToDateStatus: types.InOutInput, ToDate: newDate(2030, time.January, 1),
			PerYrStatus: types.InOutInput, PerYr: 12,
			ValStatus: types.InOutInput, Val: 0,
		}},
		PresVal: PresValLine{
			R:          RateEntry{Status: types.InOutInput, Rate: 0.06},
			AsOfStatus: types.InOutInput, AsOf: newDate(2024, time.January, 1),
			SumValueStatus: types.InOutInput, SumValue: 5000,
		},
	}
	res := Calculate(in)
	if res.Err != nil {
		t.Fatalf("From+To+Value=0 is a valid zero row in DOS, got error: %v", res.Err)
	}
	if len(res.Periodics) != 1 || res.Periodics[0].Amt != 0 {
		t.Fatalf("expected derived per-payment amount 0 for a zero-value row, got %+v", res.Periodics)
	}
}

// FirstPass periodic with peryr missing and a low core status hits the
// "else" status=LineMissing4 arm (backward.go:250-252). A periodic row
// with only a From date and peryr blank.
func TestFirstPassPeriodicPerYrMissingLowStatus(t *testing.T) {
	in := PVInput{
		Settings: defaultSettings(),
		Periodics: []PeriodicPayment{{
			FromDateStatus: types.InOutInput, FromDate: newDate(2025, time.January, 1),
			// no to, no amt, no peryr -> coreCount 1, status decremented,
			// then peryr-missing pushes below 4.
		}},
		PresVal: PresValLine{
			R:          RateEntry{Status: types.InOutInput, Rate: 0.06},
			AsOfStatus: types.InOutInput, AsOf: newDate(2024, time.January, 1),
		},
	}
	res := FirstPass(&in)
	// No assertion on classification value beyond not panicking — the row
	// is underspecified and FirstPass simply records the status.
	if res.Err != nil {
		t.Fatalf("unexpected error: %v", res.Err)
	}
}

// computeKnownRowSum skips fully-blank rows and folds in POD
// (backward.go:592, 612, 631). A PV-1 lump-amount solve runs alongside a
// completely blank lump row, a completely blank periodic row, and an
// active Payment-on-Death — the blank rows trip the skip guards while the
// POD term is added to the residual.
func TestComputeKnownRowSumSkipsAndPOD(t *testing.T) {
	asOf := dateOf(2024, time.January, 1)
	dob := dateOf(1954, time.January, 1)
	cfg := actuarialTestCfg(asOf, dob)
	cfg.POD = 50000
	in := PVInput{
		Settings: vrTestSettings(),
		LumpSums: []LumpSumPayment{
			{ // the unknown (solve amount)
				DateStatus: types.InOutInput, Date: dateOf(2030, time.January, 1),
			},
			{ // fully blank -> skipped at backward.go:592
				Date: types.UnknownDate(),
			},
		},
		Periodics: []PeriodicPayment{
			{ // fully blank -> skipped at backward.go:612
				FromDate: types.UnknownDate(), ToDate: types.UnknownDate(),
			},
		},
		PresVal: PresValLine{
			AsOfStatus: types.InOutInput, AsOf: asOf,
			R:              RateEntry{Status: types.InOutInput, Rate: 0.05},
			SumValueStatus: types.InOutInput, SumValue: 60000,
		},
		Actuarial: cfg,
	}
	res := Calculate(in)
	if res.Err != nil {
		t.Fatalf("unexpected error: %v", res.Err)
	}
	if res.LumpSums[0].AmtStatus >= types.InOutDefault {
		t.Fatalf("row 0 amount should be solved")
	}
}

// PV-2 lump-date solve: a Value far larger than the Amount implies a date
// centuries in the past (val=1e8, amt=1000, rate=0.05 → ~year 1793). DOS aborts
// the date search when the iterate leaves its [1900, 2099] window
// (PRESVALU.pas:915 `if (wdate.y>199) then count:=30`) and reports
// non-convergence — the port must match, not return the out-of-range date.
//
// Oracle provenance:
//
//	pv_oracle bk_lump_date 1e8 1000 0.05 12 → ERR "Date" computation did not converge, line 1.
func TestSolveLumpDateFarPastRefusesLikeDOS(t *testing.T) {
	in := PVInput{
		Settings: defaultSettings(),
		LumpSums: []LumpSumPayment{{
			AmtStatus: types.InOutInput, Amt: 1000,
			ValStatus: types.InOutInput, Val: 1e8, // far-past accumulation
		}},
		PresVal: PresValLine{
			AsOfStatus: types.InOutInput, AsOf: newDate(2024, time.January, 1),
			R:              RateEntry{Status: types.InOutInput, Rate: 0.05},
			SumValueStatus: types.InOutInput, SumValue: 1e8,
		},
	}
	res := Calculate(in)
	if res.Err == nil || !strings.Contains(res.Err.Error(), "did not converge") {
		t.Fatalf("want a 'did not converge' error (DOS refuses the out-of-range date); got Err=%v date=%v",
			res.Err, res.LumpSums[0].Date.Time.Year())
	}
}

// PV-9 as-of solve: an unreachable target Present Value (a value far above the
// undiscounted lump at a high rate) leaves DOS's Newton non-converged within its
// 10-step budget, so DOS reports "'As of' computation did not converge"
// (PRESVALU.pas:806) and returns no date. The port previously fell out of the
// loop and ACCEPTED the un-converged as-of; it now matches DOS. 2026-07-16 PV
// fuzzer3.
//
// Oracle provenance:
//
//	pv_oracle bk_asof 2971232.27 1313471.71 0.280035 567 → ERR "As of" computation did not converge, line 1.
func TestSolveAsOfUnreachableRefusesLikeDOS(t *testing.T) {
	_, ok := goBkAsOf(2971232.27, 1313471.71, 0.280035, 567)
	if ok {
		t.Fatalf("want the as-of solve to refuse (DOS: 'As of' did not converge); Go returned a date")
	}
}

// PV-2 lump-date solve: a Value far smaller than the Amount caps the step
// at -20 years (backward.go:794-795, the negative arm).
func TestSolveLumpDateLargeStepCapNegative(t *testing.T) {
	in := PVInput{
		Settings: defaultSettings(),
		LumpSums: []LumpSumPayment{{
			AmtStatus: types.InOutInput, Amt: 1000,
			ValStatus: types.InOutInput, Val: 0.001, // huge discount -> far future
		}},
		PresVal: PresValLine{
			AsOfStatus: types.InOutInput, AsOf: newDate(2024, time.January, 1),
			R:              RateEntry{Status: types.InOutInput, Rate: 0.5},
			SumValueStatus: types.InOutInput, SumValue: 0.001,
		},
	}
	res := Calculate(in)
	// Convergence is not the point; the negative-step clamp is exercised
	// regardless of the final outcome.
	_ = res
}
