// Package mortgage implements mortgage comparison calculations ported from
// the legacy Delphi/Pascal Mortgage.pas module.
//
// It provides the core Summation formula for present value of periodic payments,
// the Calc procedure for computing missing mortgage fields, APR iteration,
// and crossover APR comparison between two mortgages.
//
// All monetary values use float64 to match the original Pascal real type behavior.
// The caller is responsible for converting to/from decimal.Decimal at the
// boundary (API/display layer). Internal calculations must use float64 to
// preserve the exact numerical behavior of the original iterative algorithms.
//
// Ported from legacy/source/Mortgage.pas
package mortgage

import (
	"fmt"
	"math"

	"github.com/persense/persense-port/internal/finance/interest"
	"github.com/persense/persense-port/internal/types"
)

// --- Constants matching original Pascal values ---

const teeny = types.Teeny     // 1E-10
const tiny = types.Tiny       // 1E-5
const small = types.Small     // 1E-4
const twelfth = types.Twelfth // 1/12
const half = types.Half       // 0.5

// unusuallyHighTrueRate is the threshold above which a user-entered
// Loan Rate triggers a soft "looks like a typo" warning. It is the
// true (continuously-compounded) rate corresponding to 20% nominal
// annual: 12·ln(1 + 0.20/12) = 0.19835162342. Ported verbatim from
// legacy/src/dos_source/MortgageScreenUnit.pas:222 (DA_UnusuallyHighRate).
const unusuallyHighTrueRate = 0.19835162342

// MtgLine represents one row of the mortgage comparison screen with
// float64 fields for internal calculation. This mirrors the Pascal
// mortgageline record but uses native float64 for computation.
//
// Ported from legacy/source/PETYPES.PAS: mortgageline record
type MtgLine struct {
	PriceStatus    int8
	Price          float64
	PointsStatus   int8
	Points         float64
	PctStatus      int8
	Pct            float64 // downpayment percentage (0-1)
	CashStatus     int8
	Cash           float64
	FinancedStatus int8
	Financed       float64
	YearsStatus    int8
	Years          int
	RateStatus     int8
	Rate           float64 // true (continuously compounded) rate
	TaxStatus      int8
	Tax            float64
	MonthlyStatus  int8
	Monthly        float64
	WhenStatus     int8
	When           int // years to balloon
	HowMuchStatus  int8
	HowMuch        float64 // balloon amount
	BalloonStat    types.BalloonStatus
}

// ZeroMortgage initializes all fields to empty/zero.
// Ported from legacy/source/Mortgage.pas: procedure ZeroMortgage
func ZeroMortgage(m *MtgLine) {
	*m = MtgLine{BalloonStat: types.BalloonBlank}
}

// IsEmpty returns true if all data fields are empty.
// Ported from legacy/source/Mortgage.pas: function MortgageIsEmpty
func IsEmpty(m *MtgLine) bool {
	return m.PriceStatus == types.StatusEmpty &&
		m.PointsStatus == types.StatusEmpty &&
		m.PctStatus == types.StatusEmpty &&
		m.CashStatus == types.StatusEmpty &&
		m.FinancedStatus == types.StatusEmpty &&
		m.YearsStatus == types.StatusEmpty &&
		m.RateStatus == types.StatusEmpty &&
		m.TaxStatus == types.StatusEmpty &&
		m.MonthlyStatus == types.StatusEmpty &&
		m.WhenStatus == types.StatusEmpty &&
		m.HowMuchStatus == types.StatusEmpty
}

// EnoughDataForAPR returns true if the mortgage has sufficient data
// for an APR calculation (financed, monthly, rate, and years all present).
// Ported from legacy/source/Mortgage.pas: function EnoughDataForAPR
func EnoughDataForAPR(m *MtgLine) bool {
	return m.FinancedStatus > 0 && interest.OK(m.Financed) &&
		m.MonthlyStatus > 0 && interest.OK(m.Monthly) &&
		m.RateStatus > 0 && interest.OK(m.Rate) &&
		m.YearsStatus > 0 && interest.OK(float64(m.Years))
}

// --- Core calculation functions ---

// Summation computes the present value of n monthly payments discounted at
// rate r over t years. This is the core formula used throughout the mortgage
// calculations.
//
// Formula: f * (1 - last) / (1 - f)
//
//	where f = e^(-r/12), last = e^(-r*t)
//
// For zero rate, returns 12*t (undiscounted payment count).
//
// Ported from legacy/source/Mortgage.pas: function Summation
func Summation(r, t float64) (float64, error) {
	if math.Abs(r) < teeny {
		return 12 * t, nil
	}
	last, err := interest.Exxp(-r * t)
	if err != nil {
		return 0, err
	}
	f, err := interest.Exxp(-r * twelfth)
	if err != nil {
		return 0, err
	}
	// DOS computes f*(1-last)/(1-f) with no guard on (1-f) (Mortgage.pas:140).
	// The near-zero-rate case is already handled by the abs(r)<teeny branch
	// above; for any r>=teeny, Exxp's Taylor branch returns f strictly less
	// than 1 (never exactly 1), so 1-f is never zero. An extra denom guard
	// here was DOS-absent and could only mask the (unreachable) division —
	// removed to keep Summation a faithful transcription of the Pascal.
	return f * (1 - last) / (1 - f), nil
}

// CalcResult holds the output of a Calc operation, including any
// fields that were computed and any error messages.
type CalcResult struct {
	Line MtgLine // updated mortgage line with computed fields
	Err  error   // nil on success
	// Warnings carries non-fatal advisories. DOS FirstPass flags
	// some inconsistent inputs (e.g. amount borrowed exceeding price)
	// with a message but still computes — those surface here.
	Warnings []string
}

// LoanRateToTrueRate converts a user-facing loan rate (nominal
// monthly-compounded annual yield — what the help docs print as
// e.g. "8.0000" for 8%) into the continuously-compounded "true
// rate" used internally by Calc, Summation, and the APR routines.
//
// Formula: trueRate = 12 · ln(1 + loanRate/12)
//
// This mirrors the conversion the DOS app performs when the user
// enters a rate (INTSUTIL.pas: RateFromYield with n=12). Callers
// constructing an MtgLine from user input (REST handler, file
// importer, CLI) must apply this conversion before populating
// MtgLine.Rate. Callers that already hold an internal true rate
// (refdata cross-checks, intermediate solver iterations) pass the
// rate directly.
func LoanRateToTrueRate(loanRate float64) float64 {
	r, _ := interest.RateFromYield(loanRate, 12, 360.0)
	return r
}

// TrueRateToLoanRate is the inverse of LoanRateToTrueRate. Convert
// the internal continuously-compounded rate into the nominal
// monthly-compounded rate suitable for display.
//
// Formula: loanRate = 12 · (exp(trueRate/12) − 1)
//
// Mirrors INTSUTIL.pas: YieldFromRate with n=12.
func TrueRateToLoanRate(trueRate float64) float64 {
	y, _ := interest.YieldFromRate(trueRate, 12, 360.0)
	return y
}

// Calc computes missing fields for a single mortgage row.
// Given price, % down (or cash or financed), years, and rate, it can compute:
//   - Cash and financed from pct (or pct from cash/financed)
//   - Monthly payment
//   - Price (given monthly and pct or cash)
//   - Balloon amount (if when is specified but howmuch is not)
//
// Ported from legacy/source/Mortgage.pas: procedure Calc
func Calc(m MtgLine) CalcResult {
	result := CalcResult{Line: m}
	ei := &result.Line

	// FirstPass validation
	if ei.YearsStatus == types.InOutInput && ei.Years <= 0 {
		result.Err = fmt.Errorf("Years must be a positive whole number of years. Enter the loan term in the Years field, for example 30.")
		return result
	}

	// Unusually-high-rate sanity check. DOS warns when the user types a
	// Loan Rate above 20% nominal (MortgageScreenUnit.pas:222, threshold
	// 0.19835162342 — the true-rate form of 20% nominal). Almost always
	// a units slip (e.g. 60 meant as 6.0). Soft warning only: a high
	// rate is occasionally legitimate, and DOS lets the computation
	// proceed. Fire only on a user-entered rate, never on a solved one.
	if ei.RateStatus == types.InOutInput && ei.Rate > unusuallyHighTrueRate {
		result.Warnings = append(result.Warnings, fmt.Sprintf(
			"Loan Rate of about %.2f%% is unusually high — double-check it was "+
				"entered in percent (for example 6 for 6%%, not 0.06 or 600).",
			TrueRateToLoanRate(ei.Rate)*100))
	}

	// Determine balloon status
	if ei.WhenStatus == types.InOutInput {
		if ei.HowMuchStatus == types.InOutInput {
			ei.BalloonStat = types.BalloonKnown
		} else {
			ei.BalloonStat = types.BalloonUnk
		}
	} else if ei.HowMuchStatus == types.InOutInput {
		result.Err = fmt.Errorf("Balloon Amt is filled in but Balloon Yrs is blank. Enter Balloon Yrs (when the balloon is due), or clear Balloon Amt if there is no balloon.")
		return result
	} else {
		ei.BalloonStat = types.BalloonBlank
	}

	if ei.PriceStatus == types.InOutInput && ei.FinancedStatus > types.StatusEmpty &&
		ei.Financed > ei.Price {
		// DOS FirstPass (Mortgage.pas:179-184) calls RecordError here,
		// which sets errorflag (INTSUTIL.pas:1065). CalculateRows then
		// SKIPS Calc for the row (Mortgage.pas:1128-1134: "if errorflag
		// then errorflag:=false else Calc(i)"), so DOS produces NO
		// computed output — only the message. Match that refusal
		// exactly rather than computing a negative % Down / Cash.
		// Verified against the real DOS engine: `mtg_oracle mfin 100000
		// 120000 30 0.07` -> "ERR Amount borrowed cannot exceed price."
		// (a financed>price row), vs a normal solve when financed<price.
		result.Err = fmt.Errorf("Amount borrowed cannot exceed price.")
		return result
	}

	// Compute cash/pct/financed from price
	if ei.PriceStatus == types.InOutInput {
		if err := computeCashPctAndFinanced(ei); err != nil {
			result.Err = err
			return result
		}
	}

	// Main calculation: need pct/cash/financed + years + rate
	hasFunding := ei.PctStatus == types.InOutInput || ei.CashStatus == types.InOutInput || ei.FinancedStatus == types.InOutInput
	if hasFunding && ei.YearsStatus == types.InOutInput && ei.RateStatus == types.InOutInput {

		var balloonval float64
		if ei.BalloonStat == types.BalloonKnown {
			bv, err := interest.Exxp(-ei.Rate * float64(ei.When))
			if err != nil {
				result.Err = err
				return result
			}
			balloonval = ei.HowMuch * bv
		}

		if ei.PriceStatus == types.InOutInput {
			if ei.MonthlyStatus == types.InOutInput {
				// Both price and monthly specified
				if ei.BalloonStat == types.BalloonUnk {
					// Compute unknown balloon
					if err := balloonCalc(ei, balloonval); err != nil {
						result.Err = err
						return result
					}
				} else {
					result.Err = fmt.Errorf("Price and Monthly Total are both filled in, so there is nothing left to solve. Leave one of them blank for Per%%Sense to compute it, or add Balloon Yrs (leaving Balloon Amt blank) to solve for the balloon.")
					return result
				}
			} else if ei.BalloonStat != types.BalloonUnk {
				// Compute monthly from price
				summ, err := Summation(ei.Rate, float64(ei.Years))
				if err != nil {
					result.Err = err
					return result
				}
				// DOS divides here UNGUARDED (Mortgage.pas:287) and publishes the
				// quotient however large. The Go-only refusal below was both
				// non-DOS and mislabelled: Summation only falls under teeny when
				// the rate is ENORMOUS (f = exxp(-r/12) -> 0), never when it is
				// zero — a zero rate correctly takes Summation's `12*t` limb. It
				// fired from true rate ~277 upward (~1.2e11%% nominal):
				//	mtg_oracle monthly 200000 0.20 30 277 0
				//	  -> DOS monthly 1694666612242615.5 | Go refused
				// Boundary mapped: 276 agrees bit-identically, 277 diverged.
				// 2026-07-30 mortgage audit, finding 2.
				ei.Monthly = (ei.Price*(1-ei.Pct)-balloonval)/summ + ei.Tax
				ei.MonthlyStatus = types.InOutOutput
			}
		} else if ei.MonthlyStatus == types.InOutInput && ei.BalloonStat != types.BalloonUnk {
			// Compute price from monthly
			summ, err := Summation(ei.Rate, float64(ei.Years))
			if err != nil {
				result.Err = err
				return result
			}
			// DOS divides by (1 - pct) at Mortgage.pas:294 and ABORTS on pct = 1
			// (FPC raises EInvalidOp; original Turbo Pascal, runtime error 200).
			// Go's IEEE-754 division instead yielded +Inf and returned it as a
			// SUCCESS with Err == nil, which then propagated (Financed =
			// Inf*(1-1) = NaN) all the way out of the API. A deterministic refusal
			// is the faithful behaviour — DOS never publishes a number here.
			// 100%% down is a plausible cash-purchase entry, not an exotic input.
			// 2026-07-30 mortgage audit, finding 3.
			//	mtg_oracle price 1.0 30 0.07 1000 0  -> DOS EInvalidOp
			if ei.Pct == 1 {
				result.Err = fmt.Errorf("%% Down of 100%% leaves nothing financed, so Price cannot be solved from the Monthly Total. Lower %% Down, or enter Price directly.")
				return result
			}
			paymentValue := (ei.Monthly - ei.Tax) * summ

			if ei.PctStatus == types.InOutInput {
				ei.Price = (paymentValue + balloonval) / (1 - ei.Pct)
			} else if ei.CashStatus == types.InOutInput {
				ei.Price = ei.Cash + (1-ei.Points)*(paymentValue+balloonval)
			} else {
				result.Err = fmt.Errorf("Not enough data to solve for Price from Monthly Total: also fill in %% Down or Cash Required so Per%%Sense knows how the purchase is funded.")
				return result
			}

			if err := computeCashPctAndFinanced(ei); err != nil {
				result.Err = err
				return result
			}
			ei.PriceStatus = types.InOutOutput
		}
	}

	appendResultAdvisories(&result)
	return result
}

// computeCashPctAndFinanced computes the missing fields among pct, cash, financed
// given that price is known.
// Ported from legacy/source/Mortgage.pas: procedure ComputeCashPctAndFinanced
func computeCashPctAndFinanced(ei *MtgLine) error {
	if math.Abs(ei.Price) < teeny {
		return fmt.Errorf("Price must be greater than zero. Enter the purchase price in the Price field so %% Down, Cash Required and Amt Borrowed can be computed.")
	}

	if ei.PctStatus == types.InOutInput {
		ei.Cash = ei.Price * (ei.Pct + (1-ei.Pct)*ei.Points)
		ei.CashStatus = types.InOutOutput
		ei.Financed = ei.Price * (1 - ei.Pct)
		ei.FinancedStatus = types.InOutOutput
	} else if ei.CashStatus == types.InOutInput {
		// Same shape as the (1 - pct) division above: DOS aborts on points = 1
		// (Mortgage.pas:216), Go produced +Inf and returned it as a success.
		if ei.Points == 1 {
			return fmt.Errorf("Points of 100%% leaves nothing to finance, so %% Down cannot be derived from Cash Required. Lower Points, or enter %% Down directly.")
		}
		ei.Pct = (ei.Cash/ei.Price - ei.Points) / (1 - ei.Points)
		// DOS compares against an EXTENDED-precision (80-bit) 0.995
		// (Mortgage.pas:217 / :232). No float64 equals 0.995 exactly — the
		// nearest double is 0.99499999999999999556, just BELOW it — so DOS's
		// `pct >= 0.995` is effectively `pct > 0.995_exact` and a screen at
		// exactly 99.5%% down PASSES. Go's float64 `>=` refused it. That is the
		// one value users actually type: across 2000 round prices set to exactly
		// 99.5%% down, the computed pct equalled double(0.995) in 2000/2000 cases,
		// so this fired every time rather than as ULP noise. `>` reproduces DOS's
		// predicate exactly. 2026-07-30 mortgage audit, finding 1.
		//	mtg_oracle mcash 200000 199000 30 0.07 0  -> DOS monthly 6.666769
		//	mtg_oracle mfin  200000   1000 30 0.07 0  -> DOS monthly 6.666769
		if ei.Pct > 0.995 {
			return fmt.Errorf("Cash Required is within 0.5%% of Price, so %% Down would round to 100%% and Amt Borrowed cannot be solved. Lower Cash Required, or leave it blank and enter %% Down instead.")
		}
		ei.PctStatus = types.InOutOutput
		ei.Financed = ei.Price * (1 - ei.Pct)
		ei.FinancedStatus = types.InOutOutput
	} else if ei.FinancedStatus == types.InOutInput {
		ei.Pct = 1 - (ei.Financed / ei.Price)
		// DOS compares against an EXTENDED-precision (80-bit) 0.995
		// (Mortgage.pas:217 / :232). No float64 equals 0.995 exactly — the
		// nearest double is 0.99499999999999999556, just BELOW it — so DOS's
		// `pct >= 0.995` is effectively `pct > 0.995_exact` and a screen at
		// exactly 99.5%% down PASSES. Go's float64 `>=` refused it. That is the
		// one value users actually type: across 2000 round prices set to exactly
		// 99.5%% down, the computed pct equalled double(0.995) in 2000/2000 cases,
		// so this fired every time rather than as ULP noise. `>` reproduces DOS's
		// predicate exactly. 2026-07-30 mortgage audit, finding 1.
		//	mtg_oracle mcash 200000 199000 30 0.07 0  -> DOS monthly 6.666769
		//	mtg_oracle mfin  200000   1000 30 0.07 0  -> DOS monthly 6.666769
		if ei.Pct > 0.995 {
			return fmt.Errorf("Amt Borrowed is too small next to Price, so %% Down would round to 100%% and cannot be solved. Raise Amt Borrowed, or leave it blank and enter %% Down instead.")
		}
		ei.PctStatus = types.InOutOutput
		ei.Cash = ei.Price * (ei.Pct + (1-ei.Pct)*ei.Points)
		ei.CashStatus = types.InOutOutput
	}
	return nil
}

// balloonCalc computes the unknown balloon payment amount.
// Ported from legacy/source/Mortgage.pas: procedure BalloonCalc
func balloonCalc(ei *MtgLine, balloonval float64) error {
	summ, err := Summation(ei.Rate, float64(ei.Years))
	if err != nil {
		return err
	}
	bv := ei.Price*(1-ei.Pct) - (ei.Monthly-ei.Tax)*summ - balloonval
	expWhen, err := interest.Exxp(ei.Rate * float64(ei.When))
	if err != nil {
		return err
	}
	ei.HowMuch = bv * expWhen
	ei.HowMuchStatus = types.InOutOutput
	return nil
}

// --- APR calculation ---

// TerminalBalloon computes the remaining balance at time t years after loan date.
// Includes the regular payment that would be due on that date.
//
// Ported from legacy/source/Mortgage.pas: function TerminalBalloon
func TerminalBalloon(ei *MtgLine, t float64) (float64, error) {
	summ, err := Summation(ei.Rate, t-twelfth)
	if err != nil {
		return 0, err
	}
	result := ei.Financed - (ei.Monthly-ei.Tax)*summ

	if ei.BalloonStat != types.BalloonBlank && float64(ei.When) <= t {
		bv, err := interest.Exxp(-ei.Rate * float64(ei.When))
		if err != nil {
			return 0, err
		}
		result -= ei.HowMuch * bv
	}

	expRt, err := interest.Exxp(ei.Rate * t)
	if err != nil {
		return 0, err
	}
	return result * expRt, nil
}

// ValueOfPaymentsForTerminatedLoan computes the present value (as of loan date,
// using rate r) of all loan payments up to time t, including a terminal balloon at t.
//
// Ported from legacy/source/Mortgage.pas: function ValueOfPaymentsForTerminatedLoan
func ValueOfPaymentsForTerminatedLoan(ei *MtgLine, r, t float64) (float64, error) {
	summ, err := Summation(r, t-twelfth)
	if err != nil {
		return 0, err
	}
	result := (ei.Monthly - ei.Tax) * summ

	if ei.BalloonStat != types.BalloonBlank && float64(ei.When) < t {
		bv, err := interest.Exxp(-r * float64(ei.When))
		if err != nil {
			return 0, err
		}
		result += ei.HowMuch * bv
	}

	if t <= float64(ei.Years) {
		tb, err := TerminalBalloon(ei, t)
		if err != nil {
			return 0, err
		}
		discount, err := interest.Exxp(-r * t)
		if err != nil {
			return 0, err
		}
		result += tb * discount
	}

	return result, nil
}

// IterateToFindAPR uses Newton's method to find the APR of a mortgage,
// optionally terminated at time t. Returns the APR as a yield (effective rate)
// and whether the iteration converged.
//
// Ported from legacy/source/Mortgage.pas: function IterateToFindAPRofTerminatedLoan
func IterateToFindAPR(ei MtgLine, t float64, yrdays float64) (apr float64, converged bool, err error) {
	target := ei.Financed * (1 - ei.Points)
	apr = ei.Rate + ei.Points/float64(ei.Years) // first guess
	value, err := ValueOfPaymentsForTerminatedLoan(&ei, apr, t)
	if err != nil {
		return 0, false, err
	}
	oldvalue := value
	delta := small

	apr += delta
	for count := 0; count < 20; count++ {
		value, err = ValueOfPaymentsForTerminatedLoan(&ei, apr, t)
		if err != nil {
			return 0, false, err
		}
		denom := value - oldvalue
		var newdelta float64
		if math.Abs(denom) > teeny {
			newdelta = (target - value) * delta / denom
		} else {
			newdelta = small
		}
		delta = newdelta
		apr += delta
		oldvalue = value

		if math.Abs(delta) < teeny {
			break
		}
	}

	converged = math.Abs(delta) < tiny

	// Convert to yield at monthly compounding
	apr, err = interest.YieldFromRate(apr, 12, yrdays)
	if err != nil {
		return 0, false, err
	}
	return apr, converged, nil
}

// FullTermAPR computes the APR for a mortgage held to its full term.
// Ported from legacy/source/Mortgage.pas: function IterateToFindAPR
func FullTermAPR(ei MtgLine, yrdays float64) (apr float64, converged bool, err error) {
	return IterateToFindAPR(ei, float64(ei.Years)+twelfth, yrdays)
}

// OneMonthAPR computes the APR if the loan is paid off when the first
// payment is due (the worst-case APR with points).
//
// Ported from legacy/source/Mortgage.pas: function OneMonthAPR
func OneMonthAPR(ei *MtgLine, yrdays float64) (float64, error) {
	yld, err := interest.YieldFromRate(ei.Rate, 12, yrdays)
	if err != nil {
		return 0, err
	}
	aprRate := 12 * (1 + yld/12) / (1 - ei.Points)
	return interest.YieldFromRate(aprRate, 12, yrdays)
}

// APRComparisonResult holds the result of comparing two mortgages' APRs.
type APRComparisonResult struct {
	APR1          float64 // APR of mortgage 1
	APR1Converged bool
	APR2          float64 // APR of mortgage 2
	APR2Converged bool
	// CrossoverAPR and CrossoverTime are set if the APRs cross
	CrossoverAPR  float64
	CrossoverTime float64 // years
	// Summary describes which mortgage is better
	Summary string
}

// CompareAPRs compares the APRs of two mortgage lines.
//
// Ported from legacy/source/Mortgage.pas: procedure ReportComparisonOfAPRs
func CompareAPRs(e1, e2 MtgLine, yrdays float64) (APRComparisonResult, error) {
	var result APRComparisonResult

	// DOS gates the comparison on each mortgage having enough data
	// for an APR (ReportComparisonOfAPRs, Mortgage.pas:632-634) —
	// otherwise the iteration churns against an under-specified row.
	if !EnoughDataForAPR(&e1) {
		return result, fmt.Errorf("Mortgage A does not have enough data to compute an APR. Fill in Amt Borrowed, Monthly Total, Loan Rate and Years for mortgage A.")
	}
	if !EnoughDataForAPR(&e2) {
		return result, fmt.Errorf("Mortgage B does not have enough data to compute an APR. Fill in Amt Borrowed, Monthly Total, Loan Rate and Years for mortgage B.")
	}

	result.APR1, result.APR1Converged, _ = FullTermAPR(e1, yrdays)
	result.APR2, result.APR2Converged, _ = FullTermAPR(e2, yrdays)

	apr1short, err := OneMonthAPR(&e1, yrdays)
	if err != nil {
		return result, err
	}
	apr2short, err := OneMonthAPR(&e2, yrdays)
	if err != nil {
		return result, err
	}

	// Check if one mortgage is always better
	if (apr1short < apr2short && result.APR1 <= result.APR2) ||
		(apr1short <= apr2short && result.APR1 < result.APR2) {
		result.Summary = "Mortgage 1 is always better."
		return result, nil
	}
	if (apr2short < apr1short && result.APR2 <= result.APR1) ||
		(apr2short <= apr1short && result.APR2 < result.APR1) {
		result.Summary = "Mortgage 2 is always better."
		return result, nil
	}

	// Try to find crossover point
	apr, t, found, err := iterateToFindCrossoverAPRandTime(e1, e2, yrdays)
	if err != nil {
		return result, err
	}
	if found {
		result.CrossoverAPR = apr
		result.CrossoverTime = t
		// DOS-faithful duration string. The DOS engine always emits the
		// plural forms — strb(years,0)+' years' and strb(months,0)+' months'
		// (Mortgage.pas:684-690, ReportComparisonOfAPRs) — so "1 years, 1
		// months" is intentional, matching the original. Do NOT singularize:
		// the port mirrors DOS output here. The crossover only reaches this
		// code when t is positive and within both loan terms (DOS guard at
		// Mortgage.pas:534), so years/months are non-negative.
		years := int(t)
		months := int(math.Round(12 * (t - float64(years))))
		var timestr string
		if years > 0 {
			timestr = fmt.Sprintf("%d years", years)
		}
		if months != 0 {
			if timestr != "" {
				timestr += ", "
			}
			timestr += fmt.Sprintf("%d months", months)
		}
		better := "1"
		if result.APR1 >= result.APR2 {
			better = "2"
		}
		result.Summary = fmt.Sprintf("APRs cross at %.4f%% for duration %s. "+
			"If held longer than %s, Mortgage %s is better.",
			100*apr, timestr, timestr, better)
	} else {
		result.Summary = "Crossover computation did not converge."
	}

	return result, nil
}

// iterateToFindCrossoverAPRandTime finds the time and APR where two mortgages'
// APRs are equal using 2D Newton iteration.
//
// Ported from legacy/source/Mortgage.pas: function IterateToFindCrossoverAPRandTime
func iterateToFindCrossoverAPRandTime(e1, e2 MtgLine, yrdays float64) (apr, t float64, found bool, err error) {
	const maxcount = 40

	targetFn := func(e *MtgLine, r, t float64) (float64, error) {
		vpmt, err := ValueOfPaymentsForTerminatedLoan(e, r, t)
		if err != nil {
			return 0, err
		}
		return 1 - vpmt/(e.Financed*(1-e.Points)), nil
	}

	// First guesses
	t = 0.25 * float64(e1.Years+e2.Years)
	apr1, conv1, _ := FullTermAPR(e1, yrdays)
	apr2, conv2, _ := FullTermAPR(e2, yrdays)
	var r float64
	if conv1 && conv2 {
		rfy, err := interest.RateFromYield(half*(apr1+apr2), 12, yrdays)
		if err != nil {
			return 0, 0, false, err
		}
		r = rfy
	} else {
		r = half * (e1.Rate + e1.Points/t + e2.Rate + e2.Points/t)
	}

	baser := r
	baset := 1.0
	// Reset
	baset += 2
	t = baset
	r = baser

	var target1, target2 float64
	// invdet is retained across iterations to mirror DOS: it is a
	// function-level var in IterateToFindCrossoverAPRandTime, so when a
	// step hits a (near-)singular Jacobian (det ≈ 0) DOS sets overflowflag
	// but STILL computes dr/dt with the PREVIOUS iteration's invdet and
	// updates r/t before bailing out (Mortgage.pas:449-460 + the
	// `if overflowflag then count:=maxcount` in the repeat loop). The
	// non-converged r it leaves behind is what the tail reports below.
	var invdet float64

	for count := 0; count < maxcount; count++ {
		if t < 0 {
			baset += 2
			t = baset
			r = baser
		}

		// Compute partial derivatives via finite differences
		dr := tiny
		dt := small

		lasttarget1, err := targetFn(&e1, r, t)
		if err != nil {
			return 0, 0, false, err
		}
		lasttarget2, err := targetFn(&e2, r, t)
		if err != nil {
			return 0, 0, false, err
		}

		rPlus := r + dr
		t1r, err := targetFn(&e1, rPlus, t)
		if err != nil {
			return 0, 0, false, err
		}
		t2r, err := targetFn(&e2, rPlus, t)
		if err != nil {
			return 0, 0, false, err
		}
		dTarg1dr := (t1r - lasttarget1) / dr
		dTarg2dr := (t2r - lasttarget2) / dr

		lasttarget1 = t1r
		lasttarget2 = t2r
		lastt := t
		tPlus := t + dt
		target1, err = targetFn(&e1, rPlus, tPlus)
		if err != nil {
			return 0, 0, false, err
		}
		target2, err = targetFn(&e2, rPlus, tPlus)
		if err != nil {
			return 0, 0, false, err
		}
		dTarg1dt := (target1 - lasttarget1) / dt
		dTarg2dt := (target2 - lasttarget2) / dt

		det := dTarg1dt*dTarg2dr - dTarg1dr*dTarg2dt
		// DOS sets overflowflag on a singular det but does NOT skip the
		// r/t update — it runs the Newton step with the stale invdet and
		// then forces the loop to end. Reproduce that exactly.
		singular := math.Abs(det) < teeny
		if !singular {
			invdet = 1 / det
		}

		dr = (dTarg2dt*target1 - dTarg1dt*target2) * invdet
		dt = (-dTarg2dr*target1 + dTarg1dr*target2) * invdet

		r = r + dr // note: using original lastr = r before dr increment
		t = lastt + dt

		if singular {
			break
		}
		if math.Abs(target1) < teeny && math.Abs(target2) < teeny {
			break
		}
	}

	if math.Abs(target1) > tiny || math.Abs(target2) > tiny {
		// The main 2-D iteration did not converge. When a mortgage
		// carries a balloon, the crossover can sit exactly on the
		// balloon date, where the APR functions are discontinuous and
		// Newton stalls. DOS retries pinned to the balloon dates
		// (TryBalloonDates), which — on success — sets only `t` to the
		// balloon date. It then falls through and OVERWRITES the reported
		// apr with YieldFromRate(r,12) using the non-converged r left by
		// the failed main loop, and gates the whole result on that r
		// (Mortgage.pas:528-534). The balloon-date APR that TryBalloonDates
		// computes internally is discarded by DOS; earlier the port kept it
		// (returning bApr and gating on bApr), which invented crossovers DOS
		// never reports. Mirror DOS: take only the date, report on r.
		_, bT, ok := tryBalloonDates(e1, e2, yrdays)
		if !ok {
			return 0, 0, false, nil
		}
		t = bT
	}

	apr, err = interest.YieldFromRate(r, 12, yrdays)
	if err != nil {
		return 0, 0, false, err
	}
	t = twelfth * math.Trunc(12*t) // round down to prev full month

	found = t <= float64(e1.Years) && t <= float64(e2.Years) && t > 0 && r < 1 && r >= 0
	return apr, t, found, nil
}

// tryBalloonDates is the crossover fallback used when the main 2-D
// Newton iteration fails. The APR-vs-time functions are discontinuous
// at a balloon date, so the true crossover may sit exactly there.
// For each mortgage that has a balloon, it samples both mortgages'
// terminated-loan APRs just before and just after the balloon date;
// if the APR ordering flips across that date, the crossover is the
// balloon date itself.
//
// It uses IterateToFindAPR — the faithful port of the DOS routine
// IterateToFindAPRofTerminatedLoan — so the sampled APRs match what
// the rest of the comparison logic produces.
//
// Ported from legacy/src/dos_source/Mortgage.pas: function
// TryBalloonDates.
func tryBalloonDates(e1, e2 MtgLine, yrdays float64) (apr, t float64, ok bool) {
	aprAt := func(e MtgLine, when float64) (float64, bool) {
		a, conv, err := IterateToFindAPR(e, when, yrdays)
		return a, conv && err == nil
	}
	flips := func(when float64) (a1b, a2b float64, flipped bool) {
		a1b, ok1 := aprAt(e1, when)
		a1a, ok2 := aprAt(e1, when+twelfth)
		a2b, ok3 := aprAt(e2, when)
		a2a, ok4 := aprAt(e2, when+twelfth)
		if !ok1 || !ok2 || !ok3 || !ok4 {
			return 0, 0, false
		}
		return a1b, a2b, (a1b > a2b) != (a1a > a2a)
	}

	if e1.BalloonStat != types.BalloonBlank && e1.When > 0 {
		if _, a2b, flipped := flips(float64(e1.When)); flipped {
			return a2b, float64(e1.When), true
		}
	}
	if e2.BalloonStat != types.BalloonBlank && e2.When > 0 {
		if a1b, _, flipped := flips(float64(e2.When)); flipped {
			return a1b, float64(e2.When), true
		}
	}
	return 0, 0, false
}
